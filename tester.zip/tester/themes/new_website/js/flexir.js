var itemArray = new Object();
var itArr = [];
var price = 0;
var itemTotal = 0;
var itemAr = [], catAr = [], questionsArray = [], optionsArray = [];
var loadCounter = 0;
var leadCounter = 0;
var priceVal;
var cartDiscountApplied = 0;
var blockCounter = 0;
var baseUrl = '/';
var drop_location_required = 0;
var drop_location_same_city = 0;

if (document.location.href.indexOf("localhost") > -1) {
    baseUrl = '/web-front/';
}
$(document).ready(function () {



    //   var _ouibounce = ouibounce(document.getElementById('ouibounce-modal'), {
    //     aggressive: true,
    //     timer: 0,
    //     sensitivity: 40,
    //     callback: function() {  }
    //   });

    $('body').on('click', function () {
        $('#ouibounce-modal').hide();
    });

    $('#ouibounce-modal .eiButton').on('click', function () {
        $('#ouibounce-modal').hide();
    });

    $('#ouibounce-modal .modal').on('click', function (e) {
        e.stopPropagation();
    });


    if ($("#localityVal").val() != "") {
        var da1 = '{"service_id":' + service_id + ',"locality":"' + $("#localityVal").val() + '","city":"' + $("#cityVal").val() + '"}';
    } else if ($("#cityVal").val() != "") {
        var da1 = '{"service_id":' + service_id + ',"city":"' + $("#cityVal").val() + '"}';
    } else {
        var da1 = '{"service_id":' + service_id + '}';
    }


    if (pageOpened != "home") {
        closeBanner();
    }

    $.ajax({
        type: 'POST',
        url: baseUrl + 'front//RejCustomerAppWebService/AdditionalServiceInfo',
        data: {data: da1},
        dataType: 'json',
    }).done(function (data) {

        //Metatag already set in layout/main.php

        /*if(data.data.service_metadesc!=null && data.data.service_metadesc!=""){
         $('meta[name=description]').remove();
         $('head').append( '<meta name="description" content="'+data.data.service_metadesc+'">' );
         }
         if(data.data.service_metakeyword!=null && data.data.service_metakeyword!=""){
         $('meta[name=Keywords]').remove();
         $('head').append( '<meta name="Keywords" content="'+data.data.service_metakeyword+'">' );
         }
         if(data.data.service_metatitle!=null && data.data.service_metatitle!=""){
         document.title = data.data.service_metatitle;
         }*/

        if (data.data.service_desc != null && data.data.service_desc != "") {
            $(".main_features .feature_content").html(data.data.service_desc);
        }
        if (data.data.location_name != null && data.data.location_name != "") {
            var html = $("#serName").html().trim();
            $("#serName").html(html + " In " + data.data.location_name);
        } else if (data.data.city_name != null && data.data.city_name != "") {
            var html = $("#serName").html().trim();
            $("#serName").html(html + " In " + data.data.city_name);
        }
    });

    if ($("#sale_lead_id").val() != "false") {
        var da = '{"sale_lead_id":"' + $("#sale_lead_id").val() + '"}';
        $.ajax({
            type: 'POST',
            url: baseUrl + 'front/front/GetSaleLeadMasterData',
            data: da,
            dataType: 'json',
        }).done(function (data) {
            var re = JSON.stringify(data);
            var rep = JSON.parse(re);
            console.log(rep.data.discount_code);
            $('#form1 #fname').val(rep.data.firstname);
            $('#form1 #lname').val(rep.data.lastname);
            $('#form1 #phone').val(rep.data.mobile);
            $('#form1 #email').val(rep.data.email);
            $("#discount").val(rep.data.discount_code);
            var da = '{"service_id":"' + rep.data.service_required + '", "coupon_code": "' + rep.data.discount_code + '", "city":"' + rep.data.city + '", "phone":"' + rep.data.mobile + '", "source":"2"}';
            $.ajax({
                type: 'POST',
                url: baseUrl + 'front/RejCustomerAppWebService/validateCoupon',
                data: da,
                dataType: 'json',
            }).done(function (data) {
                var re = JSON.stringify(data);
                var rep = JSON.parse(re);
                //console.log(rep.data.message);
                $('#dis_error').text(rep.data.message).show();
                apply_coupon_clicked(rep.data.message);
            });
            $("#discount").hide();
            leadCounter = 1;
        });
    }
    new flickerplate('.flicker-example');
    $("#banner5").click(function () {
        window.location = "https://zimmber.com/Electrical-Repairing-Services";
    });
    if (localStorage.getItem("fname_c")) {
        $('#form1 #fname').val(localStorage.getItem("fname_c"));
        $('#form1 #lname').val(localStorage.getItem("lname_c"));
        $('#form1 #phone').val(localStorage.getItem("phone_c"));
        $('#form1 #email').val(localStorage.getItem("email_c"));
        $('#form3 input[name=flat_no]').val(localStorage.getItem("address_c"));
        $('#form3 input[name=landmark]').val(localStorage.getItem("landmark_c"));
        $('#form2 #fname').val(localStorage.getItem("fname_c"));
        $('#form2 #lname').val(localStorage.getItem("lname_c"));
        $('#form2 #phone').val(localStorage.getItem("phone_c"));
        $('#form2 input[name=flat_no]').val(localStorage.getItem("address_c"));
        $('#form2 input[name=landmark]').val(localStorage.getItem("landmark_c"));
    }

    $('#geo_latlon').val('');
    //citySet();
    //createWeeklycalendar(10)

    if (service_id == 68) {
        $(".header_city").hide();
        $(".date_time_new").html('<div style="padding: 12px;font-weight:bold;text-align: center;font-size: 13px;">Our representative will call you by tomorrow noon.</div>');
        $(".date_time_new").css("min-height", "60px");
        $("#order_location").hide();
    }

    if (!localStorage.getItem("geo_lat") && service_id == 68) {
        localStorage.setItem("geo_lat", "19.1827551");
        localStorage.setItem("geo_lon", "19.1827551");
        localStorage.setItem("geo_city", "Malad West");
        localStorage.setItem("geo_city_id", "14");
        localStorage.setItem("geo_loc_name", "Malad West");
    }

    var da = '{"service_id":"' + service_id + '","city_id":"' + localStorage.getItem("geo_city_id") + '"}';
    $.ajax({
        type: 'POST',
        url: baseUrl + 'front//front/getnotifications',
        data: da,
        dataType: 'json',
    }).done(function (data) {
        var re = JSON.stringify(data);
        var rep = JSON.parse(re);
        if (rep.data.notify_title) {
            $(".offerHead").html(rep.data.notify_title);
        }
        if (rep.data.notify_desc) {
            $(".offerBody").html(rep.data.notify_desc);
        }
        if (rep.data.button_txt) {
            $(".eiButton").html(rep.data.button_txt);
        }

    });

    if (localStorage.getItem("geo_lat")) {
        var geo_lat = localStorage.getItem("geo_lat");
        var geo_lon = localStorage.getItem("geo_lon");
        $(".h_time").show();
        $(".h_time1").hide();

        $('#location_se').val(localStorage.getItem("geo_city"));
        $('#geo_location1').val(localStorage.getItem("geo_city"));
        $('#psuedoLocation').val(localStorage.getItem("geo_city"));
        $('#order_location').val(localStorage.getItem("geo_city"));
        $('#geo_lat').val(localStorage.getItem("geo_lat"));
        $('#geo_lon').val(localStorage.getItem("geo_lon"));
        $("#city").val(localStorage.getItem("geo_city_id"));
        $("#geo_loc_name").val(localStorage.getItem("geo_loc_name"));

        if (typeof service_id !== 'undefined') {
            createWeeklycalendar(service_id);
            $('#svn').val(service_id);
        }

        $('.close').show();

        var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "displaymode":"frontend", "AdeviceType":"lite"}';
        $.ajax({
            type: 'GET',
            url: baseUrl + 'front/RejCustomerAppWebService/menuList',
            data: {data: da},
            dataType: 'json',
        }).done(function (data) {
            var re = JSON.stringify(data);
            var rep = JSON.parse(re);
            $('.loading2').fadeOut();
            $('#load_submit').fadeOut();
            //$("#service_name").html("<option value=''>Which service are you looking for?</option>");

            // $.each(rep.data.getMenuList, function(index, value) {
            //     if(value.available === 1) {
            //         $("#service_name").append("<option value='"+ value.service_url +"'>"+value.name+"</option>");
            //     }
            // 	if(typeof service_id !== 'undefined'){
            // 	 if(value.available === 0 && value.id === service_id){
            // 		$('#myModal2').modal({
            // 					backdrop: 'static',
            // 					keyboard: true
            // 		});
            // 	 	return false;
            // 	 }
            // 	}
            //     //alert(index + ': ' + value.id + ': ' +value.name);
            // });

            // TODO: Duplicate Code. Revamping Full File Required
            var optGroups = {};
            $.each(rep.data.serviceGroup, function (ind, va) {
                if (va.services.length > 0) {
                    optGroups[va.name] = [];
                }
            });

            var serviceIdToGroupMap = {};
            $.each(rep.data.serviceGroup, function (ind, va) {
                if (va.services.length > 0) {
                    $.each(va.services, function (index, val) {
                        serviceIdToGroupMap[val.id] = va.name;
                        //document.getElementById('HeaderTopservices'+val.id).href='javascript:void(0)';
                    });
                }
            });

            /*var serviceIdToGroupMap = {
             "68": "Deep Cleaning",
             "6": "Handyman Services",
             "26": "Handyman Services",
             "42": "Handyman Services",
             "29": "Appliance Repair",
             "59": "Appliance Repair",
             "60": "Appliance Repair",
             "61": "Appliance Repair",
             "62": "Appliance Repair",
             "57": "Appliance Repair",
             "58": "Deep Cleaning",
             "47": "Deep Cleaning",
             "49": "Deep Cleaning",
             "51": "Deep Cleaning",
             "84": "Deep Cleaning",
             "86": "Deep Cleaning",
             "53": "Pest Control",
             "82": "Deep Cleaning",
             "63": "Marketplace Services",
             "87": "Marketplace Services",
             "88": "Marketplace Services",
             "89": "Marketplace Services",
             "90": "Marketplace Services",
             "91": "Marketplace Services",
             "93": "Marketplace Services",
             "94": "Marketplace Services",
             "95": "Marketplace Services",
             "96": "Marketplace Services",
             "97": "Marketplace Services",
             };*/

            $.each(rep.data.getMenuList, function (index, value) {
                if (value.available === 1) {
                    var city = localStorage.getItem("geo_city_id");
                    var service_url = value.service_url;
                    var service_url_city = service_url.replace('$city_id', city);
                    var option = {
                        value: service_url_city,
                        html: value.name
                    };
                    thisOptGroup = serviceIdToGroupMap[value.id];
                    (optGroups[thisOptGroup] || optGroups['Other Services']).push(option);
                }
                if (typeof service_id !== 'undefined') {
                    if (value.available === 0 && value.id === service_id) {
                        $('#myModal2').modal({
                            backdrop: 'static',
                            keyboard: true
                        });
                        return false;
                    }
                }
                $('#geo_latlon').val("");
            });
            var option = {
                value: '/quikrlandingpage?service_id=',
                html: '<span style="font-style: italic; color: blue;">More Services</span>'
            };
            thisOptGroup = "Marketplace Services";
            (optGroups[thisOptGroup]).push(option);
            Object.keys(optGroups).forEach(function (optGroup) {
                var thisGroup = optGroups[optGroup];
                var optionGroup = document.createElement('optgroup');
                optionGroup.setAttribute('label', optGroup);
                if (thisGroup.length) {
                    thisGroup.forEach(function (opt) {
                        var option = document.createElement('option');
                        option.setAttribute('value', opt.value);
                        if (opt.value == '/quikrlandingpage?service_id=') {
                            option.setAttribute('style', 'font-style: italic !important; color: blue !important;-webkit-text-fill-color: blue;')
                        }
                        option.innerHTML = opt.html;
                        optionGroup.appendChild(option);
                    });
                    $("#service_name").append(optionGroup);
                }
            });

            if (typeof service_id !== 'undefined') {
                $("select#service_name").val(service_id);
                $.ajax({
                    url: baseUrl + "Progressive/website/GetServiceData/service_id/" + service_id + "/city_id/" + localStorage.getItem("geo_city_id"),
                    contentType: "application/json; charset=utf-8",
                    success: function (data) {
                        rate_card_loaded(service_id);
                        var tep = $.parseJSON(data);
                        //console.log(data);
                        $.each(tep, function (index, value) {
                            //console.log(index + ': ' + value.service_name);
                            if (value.service_category_name) {
                                var cat_name = '- ' + value.service_category_name;
                            }
                            else {
                                var cat_name = '';
                            }
                            if (service_id != 68) {
                                $('#city-na').text("- " + localStorage.getItem("geo_city"));
                            }

                            //$('#items_title').text(value.service_name+' '+cat_name);
                            $('#nab').append('<li role="presentation"><a href="#tab' + index + '" aria-controls="tab' + index + '" role="tab" data-toggle="tab">' + value.service_name + ' <span>' + cat_name + '</span></a></li>');
                            if (index === 0) {
                                $('#nab-con').append('<div role="tabpanel" class="tab-pane active" id="tab' + index + '"><div class="items_title"><h1 id="items_title">' + value.service_name + ' ' + cat_name + ' </h1><div class="clear"> </div></div></div>');
                            } else {
                                $('#nab-con').append('<div role="tabpanel" class="tab-pane" id="tab' + index + '"><div class="items_title"><h1 id="items_title">' + value.service_name + ' ' + cat_name + ' </h1><div class="clear"> </div></div></div>');
                            }
                            $.each(value.item, function (a, val) {
                                //console.log(index + ': ' + val.item_name);
                                if (val.item_desc == undefined) {
                                    val.item_desc = "";
                                }
                                if (val.strike_price > 0) {
                                    $('#tab' + index).append('<div class="items_select"><div class="row"> <div class="col-md-7"> <h3>' + val.item_name + '</h3><p>' + val.item_desc + '</p> </div><div class="col-md-5"> <h2><i class="fa fa-inr"></i> <s>' + val.strike_price + '</s> ' + val.price + '</h2> </div></div></div>');
                                } else {
                                    var itemDiv = '<div class="items_select"><div class="row"> <div class="col-md-7"> <h3>' + val.item_name + '</h3><p>' + val.item_desc + '</p> </div><div class="col-md-5"> <h2>';
                                    if (!isNaN(val.price)) {
                                        itemDiv += '<i class="fa fa-inr"></i> ';
                                    }
                                    itemDiv += val.price + '</h2> </div></div></div>';
                                    $('#tab' + index).append(itemDiv);
                                }

                            });
                            $('#tab' + index).append('<div class="rate_text" id="rate_text">' + value.concat_desc + '</div>');
                            $('.loading').fadeOut();
                        });
                    }
                });
            }
        });

        $.ajax({
            url: baseUrl + "Progressive/website/GetAnswers",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                optionsArray = $.parseJSON(data);
            }
        });

        var questionsData = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "service_id":' + service_id + '}';
        var settings = {
            "async": true,
            "crossDomain": true,
            //"url": "https://webservice.zimmbatic.in/front/RejCustomerAppWebService/questions",
            "url": baseUrl + "front/RejCustomerAppWebService/questions",
            "method": "POST",
            "dataType": 'json',
            "headers": {
                "content-type": "application/x-www-form-urlencoded"
            },
            "data": {
                "data": questionsData
            }
        };

        var questionData, parsedQuestions;
        var is_drop_location = 0;

        $.ajax(settings).done(function (response) {
            questionData = JSON.stringify(response);
            parsedQuestions = JSON.parse(questionData);
            //alert(parserdQuestions.data.questions.length);
            $.each(parsedQuestions.data.questions, function (index, val) {
                questionsArray[index] = new Object();
                questionsArray[index].id = val.id;
                questionsArray[index].required = val.required;
                questionsArray[index].type = val.type;
                questionsArray[index].value = val.value;
                questionsArray[index].hint = val.hint;
                questionsArray[index].answers = val.answers;
            });
            if (questionsArray.length != 0) {
                $("#catDiv").hide();
                $("#form2Terms").show();
                $(".loading2").hide();
                $(".lists_card_title").html("Please answer certain questions");
                $(".lists_card_title").hide();
                $("#btn_rate_card").attr("onclick", "checkQuestions()");
                $(".total_cart").hide();
                loadCounter = 1;
                for (var i = 0; i < questionsArray.length; i++) {
                    if (questionsArray[i].required == 1) {
                        var req = " *";
                    } else {
                        var req = "";
                    }
                    if (questionsArray[i].type == 1) {
                        var html = '<div class="car_type" id="radio' + questionsArray[i].id + '"><div class="col-md-12"><small><i class="fa fa-th-large"></i>&nbsp;&nbsp;' + questionsArray[i].value + req + '</small><div class="select_activity pad"><div class="all_activity_selected"><form><div class="checkbox">';
                        for (var j = 0; j < questionsArray[i].answers.length; j++) {
                            if (is_drop_location < questionsArray[i].answers[j].is_drop_location) {
                                is_drop_location = questionsArray[i].answers[j].is_drop_location;
                            }
                            html += '<input id="check' + questionsArray[i].answers[j].id + '" type="radio" onclick="showQuesFeedback(' + i + ',' + j + ')" name="check' + questionsArray[i].id + '" value="' + questionsArray[i].answers[j].id + '"><label for="check' + questionsArray[i].answers[j].id + '">' + questionsArray[i].answers[j].value + '</label><br>';
                        }
                        html += '<p id="msginfo' + i + '" class="msgInfo">NOTE: User registered on Website may differ booking status on mobile</p></div><div class="date_error" id="er' + questionsArray[i].id + '">Please select an answer</div></form></div></div></div><div class="clear"></div></div>';
                        $("#tab_content").append(html);
                    }
                    if (questionsArray[i].type == 2) {
                        var html = '<div class="car_type" id="checkboxbutton' + questionsArray[i].id + '"><div class="col-md-12"><small><i class="fa fa-th-large"></i>&nbsp;&nbsp;' + questionsArray[i].value + req + '</small><div class="select_activity pad"><div class="all_activity_selected"><form><div class="checkbox checkboxer">';
                        for (var j = 0; j < questionsArray[i].answers.length; j++) {
                            if (is_drop_location < questionsArray[i].answers[j].is_drop_location) {
                                is_drop_location = questionsArray[i].answers[j].is_drop_location;
                            }
                            html += '<input id="check' + questionsArray[i].answers[j].id + '" type="checkbox" onclick="showQuesFeedback(' + i + ',' + j + ')" name="check' + questionsArray[i].id + '[]" value="' + questionsArray[i].answers[j].id + '"><label for="check' + questionsArray[i].answers[j].id + '">' + questionsArray[i].answers[j].value + '</label><br>';
                        }
                        html += '<p id="msginfo' + i + '" class="msgInfo">NOTE: User registered on Website may differ booking status on mobile</p></div><div class="date_error" id="er' + questionsArray[i].id + '">Please select an answer</div></form></div></div></div><div class="clear"></div></div>';
                        $("#tab_content").append(html);
                    }
                    if (questionsArray[i].type == 3) {
                        var html = '<div class="car_type" id="textareasection' + questionsArray[i].id + '"><div class="col-md-12"><small><i class="fa fa-th-large"></i>&nbsp;&nbsp;' + questionsArray[i].value + req + '</small><div class="select_activity pad"><div class="all_activity_selected"><form><div class="checkboxer"><p></p>';
                        html += '<textarea rows="3" cols="50" placeholder="' + questionsArray[i].hint + '" id="textarea' + questionsArray[i].id + '"></textarea>';
                        html += '</div><div class="date_error" id="er' + questionsArray[i].id + '">Please enter a description</div></form></div></div></div><div class="clear"></div></div>';
                        $("#tab_content").append(html);
                    }
                }
                var dod_drop_location = document.getElementById("dod_drop_location");
                if (is_drop_location > 0) {
                    dod_drop_location.style.display = "block";
                } else {
                    dod_drop_location.style.display = "none";
                }
            } else if ($("#cart_type").html().trim() != 0) {
                var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "serviceId":' + service_id + '}';
                $.ajax({
                    type: 'POST',
                    url: baseUrl + 'front//RejCustomerAppWebService/getCartDetails/ver/120',
                    data: {data: da},
                    dataType: 'json',
                }).done(function (data) {
                    var servicesData = JSON.stringify(data);
                    var parserdServices = JSON.parse(servicesData);
                    var counter = 0;
                    var firstCategory = "", category_name = "";
                    var subcatArray = [];
                    var catAr = [];
                    $.each(parserdServices.data.sub_category, function (index2, value2) {
                        subcatArray[value2.sub_category_id] = value2.sub_category_name;
                    });
                    $.each(parserdServices.data.cart_item, function (index, value) {
                        //categoryArray[value.category_id] =value.category_id);
                        if (!itemArray[value.category_id]) {
                            itemArray[value.category_id] = new Object();
                            itemArray[value.category_id]['subcatcheck'] = 0;
                            itemArray[value.category_id]['subcatcheckValue'] = [];
                        }
                        if (value.sub_category_id != 0) {
                            if (itemArray[value.category_id]['subcatcheckValue'].indexOf(subcatArray[value.sub_category_id]) <= -1) {
                                itemArray[value.category_id]['subcatcheckValue'].push(subcatArray[value.sub_category_id]);
                            }
                            itemArray[value.category_id]['subcatcheck'] = 1;
                        }
                        itemArray[value.category_id].subcategory_name = [];
                        itemArray[value.category_id][value.item_id] = new Object();
                        itemArray[value.category_id][value.item_id].item_name = value.item_name;
                        itemArray[value.category_id][value.item_id].service_id = value.service_id;
                        itemArray[value.category_id][value.item_id].subcategory_id = value.sub_category_id;
                        itemArray[value.category_id][value.item_id].subcategory_name = subcatArray[value.sub_category_id];
                        itemArray[value.category_id][value.item_id].price = value.price;
                        itemArray[value.category_id][value.item_id].display_price = value.price;
                        itemArray[value.category_id][value.item_id].strike_price = value.strike_price;
                        itemArray[value.category_id][value.item_id].item_desc = value.item_desc;
                        itemArray[value.category_id][value.item_id].max_quantity = value.max_quantity;
                        itArr[value.item_id] = 0;
                        catAr.push(value.category_id);
                    });
                    var ser_name = $("#serName").html().trim();
                    var uniqueNames = [];
                    var count = 0;
                    $.each(catAr, function (i, el) {
                        if ($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
                    });


                    $.each(parserdServices.data.category, function (index1, value1) {
                        // class="active"
                        if (uniqueNames.indexOf(value1.category_id) > -1) {
                            if (count == 0) {
                                firstCategory = value1.category_id;
                                category_name = value1.category_name;
                                var classVal = "active";
                                count = 1;
                            } else {
                                var classVal = "";
                            }
                            var html = '<li role="presentation"><a classVal href="#salon_tab_' + value1.category_id + '" onclick="showItems(' + value1.category_id + ')" class="salon_links" aria-controls="salon_tab_' + value1.category_id + '" role="tab" data-toggle="tab"><paper-ripple class="rate_ripple"></paper-ripple><div class="links_content" style="margin-left: 5px;"><h6 id="val' + value1.category_id + '">' + value1.category_name + '</h6></div><span><i class="fa fa-angle-right"></i></span><div class="clear"> </div></a></li>';
                            $('#serviceList').append(html);
                        }
                    });
                    loadCounter = 1;
                    $('.loading2').hide();
                    showItems(firstCategory);
                });
            } else {
                $("#form2").hide();
            }
        });

    }
    else {
        if (pageOpened == "home") {
            $('#geoModal').modal({
                backdrop: 'static',
                keyboard: true
            });
            $('.close').hide();
        }
        $('.loading2').fadeOut();
        $('#load_submit').fadeOut();
    }

    $('#geoModal').on('hidden.bs.modal', function (e) {
        $('#geo_latlon').val('');
    });

    //$("#geo_location1 input[name='geo_location']").attr("id","geo_location");

    $("input[name='geo_location']").geocomplete({country: 'in'})
        .bind("geocode:result", function (event, result) {
            $('#error_geo').hide();

            $('#geo_location1').attr("error-message", "Please enter a valid location");
            var fo_address = result.formatted_address;
            var address = result.address_components;
            var latitude = result.geometry.location.lat();
            var longitude = result.geometry.location.lng();
            var sub_locality;
            var locality;
            var city;

            address.forEach(function (entry) {
                if (entry.types.indexOf("sublocality_level_2") >= 0) {
                    sub_locality = entry.long_name;
                } else if (entry.types.indexOf("sublocality_level_1") >= 0) {
                    locality = entry.long_name;
                } else if (entry.types.indexOf("locality") >= 0) {
                    city = (entry.long_name);
                }

            });

            if (locality && sub_locality) {
                $('#geo_loc_name').val(sub_locality + ', ' + locality);
            }
            else if (sub_locality && !locality) {
                $('#geo_loc_name').val(sub_locality);

            }
            else if (!sub_locality && locality) {
                $('#geo_loc_name').val(locality);

            } else {
                var res = fo_address.split(",");

                if (res.length > 1) {
                    $('#geo_loc_name').val(res[0] + ', ' + res[1]);

                } else {
                    $('#geo_loc_name').val(res);


                }

            }

            $('#geo_lat').val(latitude);
            $('#geo_lon').val(longitude);
            $('#geo_latlon').val('1');
            location_selected($('#geo_loc_name').val());
            //console.log($('#geo_latlon').val());
            $('#location').submit();
        })
        .bind("geocode:error", function (event, status) {
            //console.log("ERROR: " + status);
            return status;
        });


    $("#psuedoLocation").blur(function () {
        $('#geo_location1').val($("#psuedoLocation").val());
    });


    $("#dropLocation1").geocomplete({country: 'in'})
        .bind("geocode:result", function (event, result) {
            $('#error_geo').hide();
            var fo_address = result.formatted_address;
            var address = result.address_components;
            var latitude = result.geometry.location.lat();
            var longitude = result.geometry.location.lng();
            var sub_locality;
            var locality;
            var city;
            var country;
            var zone, zone1;
            var pincode1;
            var add = new Array();

            if (geo_lat) {
                $.ajax({
                    url: "//api.zimmber.com/ServiceGeo/v2/isInZimmberZone?latitude=" + latitude + "&longitude=" + longitude,
                    contentType: "application/json; charset=utf-8",
                    success: function (result) {
                        var res = JSON.stringify(result);
                        var repo = JSON.parse(res);
                        //alert(repo.available);
                        if (repo.available === true) {
                            if (repo.city_id != localStorage.getItem("geo_city_id")) {
                                $('#dropLocation1').attr('invalid', '');
                                $('#dropLocation1').attr("error-message", "Drop location should be in same city of pick up location");
                                $('#geo_lat_drop').val("");
                                $('#geo_lon_drop').val("");
                                $('#geo_loc_name_drop').val("");
                                $('#dropLocation1').val("");
                                return false;
                            }
                            address.forEach(function (entry) {
                                if (entry.types.indexOf("sublocality_level_2") >= 0) {
                                    sub_locality = entry.long_name;
                                    add.push(entry.long_name);
                                } else if (entry.types.indexOf("sublocality_level_1") >= 0) {
                                    locality = entry.long_name;
                                    add.push(entry.long_name);
                                } else if (entry.types.indexOf("locality") >= 0) {
                                    city = (entry.long_name);
                                    add.push(entry.long_name);
                                } else if (entry.types.indexOf("administrative_area_level_2") >= 0) {
                                    zone = (entry.long_name);
                                    add.push(entry.long_name);
                                } else if (entry.types.indexOf("administrative_area_level_1") >= 0) {
                                    zone1 = (entry.long_name);
                                    add.push(entry.long_name);
                                } else if (entry.types.indexOf("country") >= 0) {
                                    country = (entry.long_name);
                                    add.push(entry.long_name);
                                } else if (entry.types.indexOf("postal_code") >= 0) {
                                    pincode1 = (entry.long_name);
                                    add.push(entry.long_name);
                                }

                            });
                            $('#geo_lat_drop').val(latitude);
                            $('#geo_lon_drop').val(longitude);

                            if (locality && sub_locality) {
                                $('#dropLocation1').val(sub_locality + ', ' + locality);
                                $('#geo_loc_name_drop').val(sub_locality + ', ' + locality);
                            }
                            else if (sub_locality && !locality) {
                                $('#dropLocation1').val(sub_locality);
                                $('#geo_loc_name_drop').val(sub_locality);
                            }
                            else if (!sub_locality && locality) {
                                $('#dropLocation1').val(locality);
                                $('#geo_loc_name_drop').val(locality);
                            } else {
                                var res = fo_address.split(",");

                                if (res.length > 1) {
                                    $('#dropLocation1').val(res[0] + ', ' + res[1]);
                                    $('#geo_loc_name_drop').val(res[0] + ', ' + res[1]);
                                } else {
                                    $('#dropLocation1').val(res);
                                    $('#geo_loc_name_drop').val(res);
                                }

                            }
                            add.push(latitude);
                            add.push(longitude);
                            $('#dropLocation').val(add.join(","));
                            $('#geo_latlon').val("");
                        } else {
                            $('#dropLocation1').attr('invalid', '');
                            $('#dropLocation1').attr("error-message", "Sorry, we are currently not serving in your location");
                            $('#geo_lat_drop').val("");
                            $('#geo_lon_drop').val("");
                            $('#geo_loc_name_drop').val("");
                            $('#dropLocation1').val("");
                            return false;
                        }
                    }
                });
            }
            else {
                $('#dropLocation1').attr('invalid', '');
                $('#dropLocation1').attr("error-message", "Please enter a valid location");
                $('#geo_lat_drop').val("");
                $('#geo_lon_drop').val("");
                $('#geo_loc_name_drop').val("");
                $('#dropLocation1').val("");
                return false;
            }
        })
        .bind("geocode:error", function (event, status) {
            //console.log("ERROR: " + status);
            return status;
        });


    $("#pickupLocation1").geocomplete({country: 'in'})
        .bind("geocode:result", function (event, result) {
            $('#error_geo').hide();
            var fo_address = result.formatted_address;
            var address = result.address_components;
            var latitude = result.geometry.location.lat();
            var longitude = result.geometry.location.lng();
            var sub_locality;
            var locality;
            var city;
            var country;
            var zone, zone1;
            var pincode1;
            var add = new Array();

            address.forEach(function (entry) {
                if (entry.types.indexOf("sublocality_level_2") >= 0) {
                    sub_locality = entry.long_name;
                    add.push(entry.long_name);
                } else if (entry.types.indexOf("sublocality_level_1") >= 0) {
                    locality = entry.long_name;
                    add.push(entry.long_name);
                } else if (entry.types.indexOf("locality") >= 0) {
                    city = (entry.long_name);
                    add.push(entry.long_name);
                } else if (entry.types.indexOf("administrative_area_level_2") >= 0) {
                    zone = (entry.long_name);
                    add.push(entry.long_name);
                } else if (entry.types.indexOf("administrative_area_level_1") >= 0) {
                    zone1 = (entry.long_name);
                    add.push(entry.long_name);
                } else if (entry.types.indexOf("country") >= 0) {
                    country = (entry.long_name);
                    add.push(entry.long_name);
                } else if (entry.types.indexOf("postal_code") >= 0) {
                    pincode1 = (entry.long_name);
                    add.push(entry.long_name);
                }

            });
            if (locality && sub_locality) {
                $('#pickupLocation1').val(sub_locality + ', ' + locality);
            }
            else if (sub_locality && !locality) {
                $('#pickupLocation1').val(sub_locality);

            }
            else if (!sub_locality && locality) {
                $('#pickupLocation1').val(locality);

            } else {
                var res = fo_address.split(",");

                if (res.length > 1) {
                    $('#pickupLocation1').val(res[0] + ', ' + res[1]);

                } else {
                    $('#pickupLocation1').val(res);


                }

            }
            add.push(latitude);
            add.push(longitude);
            $('#pickupLocation').val(add.join(","));
        })
        .bind("geocode:error", function (event, status) {
            //console.log("ERROR: " + status);
            return status;
        });


    $('#location').submit(function () {
        $('#error_geo').hide();
        locate_me_clicked();
        if ($('#geo_latlon').val() === "1") {
            var geo_location = $('#geo_location').val();
            var geo_lat = $('#geo_lat').val();

            var geo_lon = $('#geo_lon').val();
            $(".h_time").show();
            $(".h_time1").hide();
            $('#error1').hide();

            //console.log(geo_lat);
            /*if(geo_location.trim() === ""){
             $('#error_geo').text("Please Enter a location").show();
             return false;
             }*/

            if (geo_lat) {
                $.ajax({
                    url: "//api.zimmber.com/ServiceGeo/v2/isInZimmberZone?latitude=" + geo_lat + "&longitude=" + geo_lon,
                    contentType: "application/json; charset=utf-8",
                    success: function (result) {
                        var res = JSON.stringify(result);
                        var repo = JSON.parse(res);
                        //alert(repo.available);
                        if (repo.available === true) {
                            $('#geoModal').modal('hide');
                            localStorage.removeItem("geo_lat");
                            localStorage.removeItem("geo_lon");
                            localStorage.removeItem("geo_city");
                            localStorage.removeItem("geo_city_id");
                            localStorage.removeItem("geo_loc_name");
                            localStorage.setItem("geo_lat", geo_lat);
                            localStorage.setItem("geo_lon", geo_lon);
                            localStorage.setItem("geo_city", $("#geo_loc_name").val());
                            localStorage.setItem("geo_city_id", repo.city_id);
                            sessionStorage.setItem("geo_city_id", repo.city_id);
                            localStorage.setItem("geo_loc_name", $("#geo_loc_name").val());
                            $('#location_se').val($("#geo_loc_name").val());
                            $('input[name="geo_location"]').val($("#geo_loc_name").val());
                            $('#geo_location1').val($("#geo_loc_name").val());
                            $('.close').show();
                            $("#order_location").val(localStorage.getItem("geo_city"));
                            $("#city").val(localStorage.getItem("geo_city_id"));
                            $('#geo_lat').val(localStorage.getItem("geo_lat"));
                            $('#geo_lon').val(localStorage.getItem("geo_lon"));
                            //$('#geo_location').val("");
                            $('#error_geo').hide();


                            //Getting services list from Lat & Lng
                            var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "displaymode":"frontend", "AdeviceType":"lite"}';
                            $.ajax({
                                type: 'GET',
                                url: baseUrl + 'front/RejCustomerAppWebService/menuList',
                                data: {data: da},
                                dataType: 'json',
                            }).done(function (data) {
                                var re = JSON.stringify(data);
                                var rep = JSON.parse(re);
                                $("#service_name").empty();
                                $("#service_name").html('<option value="" selected>Which service are you looking for?</option>');

                                $.each(rep.data.getMenuList, function (index, value) {
                                    if (typeof service_id !== 'undefined') {
                                        if (value.available === 0 && value.id === service_id) {
                                            $('#myModal2').modal({
                                                backdrop: 'static',
                                                keyboard: true
                                            });
                                            return false;
                                        }
                                    }
                                });

                                // TODO: Duplicate Code. Revamping Full File Required
                                /*var optGroups = {
                                 "Deep Cleaning": [],
                                 "Appliance Repair": [],
                                 "Handyman Services": [],
                                 "Pest Control": [],
                                 "Marketplace Services": [],
                                 "Other Services": [],
                                 };
                                 var serviceIdToGroupMap = {
                                 "68": "Deep Cleaning",
                                 "6": "Handyman Services",
                                 "26": "Handyman Services",
                                 "42": "Handyman Services",
                                 "29": "Appliance Repair",
                                 "59": "Appliance Repair",
                                 "60": "Appliance Repair",
                                 "61": "Appliance Repair",
                                 "62": "Appliance Repair",
                                 "57": "Appliance Repair",
                                 "58": "Deep Cleaning",
                                 "47": "Deep Cleaning",
                                 "49": "Deep Cleaning",
                                 "51": "Deep Cleaning",
                                 "84": "Deep Cleaning",
                                 "86": "Deep Cleaning",
                                 "53": "Pest Control",
                                 "82": "Deep Cleaning",
                                 "63": "Marketplace Services",
                                 "87": "Marketplace Services",
                                 "88": "Marketplace Services",
                                 "89": "Marketplace Services",
                                 "90": "Marketplace Services",
                                 "91": "Marketplace Services",
                                 "93": "Marketplace Services",
                                 "94": "Marketplace Services",
                                 "95": "Marketplace Services",
                                 "96": "Marketplace Services",
                                 "97": "Marketplace Services",
                                 };*/
                                var optGroups = {};
                                $.each(rep.data.serviceGroup, function (ind, va) {
                                    if (va.services.length > 0) {
                                        optGroups[va.name] = [];
                                    }
                                });

                                var serviceIdToGroupMap = {};
                                $.each(rep.data.serviceGroup, function (ind, va) {
                                    if (va.services.length > 0) {
                                        $.each(va.services, function (index, val) {
                                            serviceIdToGroupMap[val.id] = va.name;
                                            //document.getElementById('HeaderTopservices'+val.id).href='javascript:void(0)';
                                        });
                                    }
                                });

                                $.each(rep.data.getMenuList, function (index, value) {
                                    if (value.available === 1) {
                                        var city = localStorage.getItem("geo_city_id");
                                        var service_url = value.service_url;
                                        var service_url_city = service_url.replace('$city_id', city);
                                        var option = {
                                            value: service_url_city,
                                            html: value.name
                                        };
                                        thisOptGroup = serviceIdToGroupMap[value.id];
                                        (optGroups[thisOptGroup] || optGroups['Other Services']).push(option);
                                    }
                                    $('#geo_latlon').val("");
                                });
                                var option = {
                                    value: '/quikrlandingpage?service_id=',
                                    html: '<u><span style="font-style: italic; color: blue;">More Services</span></u>'
                                };
                                thisOptGroup = "Marketplace Services";
                                (optGroups[thisOptGroup]).push(option);
                                Object.keys(optGroups).forEach(function (optGroup) {
                                    var thisGroup = optGroups[optGroup];
                                    var optionGroup = document.createElement('optgroup');
                                    optionGroup.setAttribute('label', optGroup);
                                    if (thisGroup.length) {
                                        thisGroup.forEach(function (opt) {
                                            var option = document.createElement('option');
                                            option.setAttribute('value', opt.value);
                                            if (opt.value == '/quikrlandingpage?service_id=') {
                                                option.setAttribute('style', 'font-style: italic !important; color: blue !important;-webkit-text-fill-color: blue;')
                                            }
                                            option.innerHTML = opt.html;
                                            optionGroup.appendChild(option);
                                        });
                                        $("#service_name").append(optionGroup);
                                    }
                                });
                            });

                            $.ajax({
                                url: baseUrl + "Progressive/website/GetAnswers",
                                contentType: "application/json; charset=utf-8",
                                success: function (data) {
                                    optionsArray = $.parseJSON(data);
                                }
                            });

                            var questionsData = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "service_id":' + service_id + '}';
                            var settings = {
                                "async": true,
                                "crossDomain": true,
                                "url": "/front/RejCustomerAppWebService/questions",
                                "method": "POST",
                                "dataType": 'json',
                                "headers": {
                                    "content-type": "application/x-www-form-urlencoded"
                                },
                                "data": {
                                    "data": questionsData
                                }
                            };

                            var questionData, parsedQuestions;

                            $.ajax(settings).done(function (response) {
                                questionData = JSON.stringify(response);
                                parsedQuestions = JSON.parse(questionData);
                                //alert(parserdQuestions.data.questions.length);
                                $.each(parsedQuestions.data.questions, function (index, val) {
                                    questionsArray[index] = new Object();
                                    questionsArray[index].id = val.id;
                                    questionsArray[index].required = val.required;
                                    questionsArray[index].type = val.type;
                                    questionsArray[index].value = val.value;
                                    questionsArray[index].hint = val.hint;
                                    questionsArray[index].answers = val.answers;
                                });
                                if (questionsArray.length != 0) {
                                    $("#catDiv").hide();
                                    $("#form2Terms").show();
                                    $(".loading2").hide();
                                    $(".lists_card_title").html("Please answer certain questions");
                                    $(".lists_card_title").hide();
                                    $("#btn_rate_card").attr("onclick", "checkQuestions()");
                                    $(".total_cart").hide();
                                    loadCounter = 1;
                                    for (var i = 0; i < questionsArray.length; i++) {
                                        if (questionsArray[i].required == 1) {
                                            var req = " *";
                                        } else {
                                            var req = "";
                                        }
                                        if (questionsArray[i].type == 1) {
                                            var html = '<div class="car_type" id="radio' + questionsArray[i].id + '"><div class="col-md-12"><small><i class="fa fa-th-large"></i>&nbsp;&nbsp;' + questionsArray[i].value + req + '</small><div class="select_activity pad"><div class="all_activity_selected"><form><div class="checkbox">';
                                            for (var j = 0; j < questionsArray[i].answers.length; j++) {
                                                html += '<input id="check' + questionsArray[i].answers[j].id + '" type="radio" onclick="showQuesFeedback(' + i + ',' + j + ')" name="check' + questionsArray[i].id + '" value="' + questionsArray[i].answers[j].id + '"><label for="check' + questionsArray[i].answers[j].id + '">' + questionsArray[i].answers[j].value + '</label><br>';
                                            }
                                            html += '<p id="msginfo' + i + '" class="msgInfo">NOTE: User registered on Website may differ booking status on mobile</p></div><div class="date_error" id="er' + questionsArray[i].id + '">Please select an answer</div></form></div></div></div><div class="clear"></div></div>';
                                            $("#tab_content").append(html);
                                        }
                                        if (questionsArray[i].type == 2) {
                                            var html = '<div class="car_type" id="checkboxbutton' + questionsArray[i].id + '"><div class="col-md-12"><small><i class="fa fa-th-large"></i>&nbsp;&nbsp;' + questionsArray[i].value + req + '</small><div class="select_activity pad"><div class="all_activity_selected"><form><div class="checkbox checkboxer">';
                                            for (var j = 0; j < questionsArray[i].answers.length; j++) {
                                                html += '<input id="check' + questionsArray[i].answers[j].id + '" type="checkbox" onclick="showQuesFeedback(' + i + ',' + j + ')" name="check' + questionsArray[i].id + '[]" value="' + questionsArray[i].answers[j].id + '"><label for="check' + questionsArray[i].answers[j].id + '">' + questionsArray[i].answers[j].value + '</label><br>';
                                            }
                                            html += '<p id="msginfo' + i + '" class="msgInfo">NOTE: User registered on Website may differ booking status on mobile</p></div><div class="date_error" id="er' + questionsArray[i].id + '">Please select an answer</div></form></div></div></div><div class="clear"></div></div>';
                                            $("#tab_content").append(html);
                                        }
                                        if (questionsArray[i].type == 3) {
                                            var html = '<div class="car_type" id="textareasection' + questionsArray[i].id + '"><div class="col-md-12"><small><i class="fa fa-th-large"></i>&nbsp;&nbsp;' + questionsArray[i].value + req + '</small><div class="select_activity pad"><div class="all_activity_selected"><form><div class="checkboxer"><p></p>';
                                            html += '<textarea rows="3" cols="50" placeholder="' + questionsArray[i].hint + '" id="textarea' + questionsArray[i].id + '"></textarea>';
                                            html += '</div><div class="date_error" id="er' + questionsArray[i].id + '">Please enter a description</div></form></div></div></div><div class="clear"></div></div>';
                                            $("#tab_content").append(html);
                                        }
                                    }
                                } else if ($("#cart_type").html().trim() != 0) {
                                    var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "serviceId":' + service_id + '}';
                                    $.ajax({
                                        type: 'POST',
                                        url: baseUrl + 'front/RejCustomerAppWebService/getCartDetails/ver/120',
                                        data: {data: da},
                                        dataType: 'json',
                                    }).done(function (data) {
                                        var servicesData = JSON.stringify(data);
                                        var parserdServices = JSON.parse(servicesData);
                                        var counter = 0;
                                        var firstCategory = "", category_name = "";
                                        var subcatArray = [];
                                        var catAr = [];
                                        $.each(parserdServices.data.sub_category, function (index2, value2) {
                                            subcatArray[value2.sub_category_id] = value2.sub_category_name;
                                        });
                                        $.each(parserdServices.data.cart_item, function (index, value) {
                                            //categoryArray[value.category_id] =value.category_id);
                                            if (!itemArray[value.category_id]) {
                                                itemArray[value.category_id] = new Object();
                                                itemArray[value.category_id]['subcatcheck'] = 0;
                                                itemArray[value.category_id]['subcatcheckValue'] = [];
                                            }
                                            if (value.sub_category_id != 0) {
                                                if (itemArray[value.category_id]['subcatcheckValue'].indexOf(subcatArray[value.sub_category_id]) <= -1) {
                                                    itemArray[value.category_id]['subcatcheckValue'].push(subcatArray[value.sub_category_id]);
                                                }
                                                itemArray[value.category_id]['subcatcheck'] = 1;
                                            }
                                            itemArray[value.category_id].subcategory_name = [];
                                            itemArray[value.category_id][value.item_id] = new Object();
                                            itemArray[value.category_id][value.item_id].item_name = value.item_name;
                                            itemArray[value.category_id][value.item_id].service_id = value.service_id;
                                            itemArray[value.category_id][value.item_id].subcategory_id = value.sub_category_id;
                                            itemArray[value.category_id][value.item_id].subcategory_name = subcatArray[value.sub_category_id];
                                            itemArray[value.category_id][value.item_id].price = value.price;
                                            itemArray[value.category_id][value.item_id].display_price = value.price;
                                            itemArray[value.category_id][value.item_id].strike_price = value.strike_price;
                                            itemArray[value.category_id][value.item_id].item_desc = value.item_desc;
                                            itemArray[value.category_id][value.item_id].max_quantity = value.max_quantity;

                                            itArr[value.item_id] = 0;
                                            catAr.push(value.category_id);
                                        });
                                        var ser_name = $("#serName").html().trim();
                                        var uniqueNames = [];
                                        var count = 0;
                                        $.each(catAr, function (i, el) {
                                            if ($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
                                        });


                                        $.each(parserdServices.data.category, function (index1, value1) {
                                            // class="active"
                                            if (uniqueNames.indexOf(value1.category_id) > -1) {
                                                if (count == 0) {
                                                    firstCategory = value1.category_id;
                                                    category_name = value1.category_name;
                                                    var classVal = "active";
                                                    count = 1;
                                                } else {
                                                    var classVal = "";
                                                }
                                                var html = '<li role="presentation"><a classVal href="#salon_tab_' + value1.category_id + '" onclick="showItems(' + value1.category_id + ')" class="salon_links" aria-controls="salon_tab_' + value1.category_id + '" role="tab" data-toggle="tab"><paper-ripple class="rate_ripple"></paper-ripple><div class="links_content" style="margin-left: 5px;"><h6 id="val' + value1.category_id + '">' + value1.category_name + '</h6></div><span><i class="fa fa-angle-right"></i></span><div class="clear"> </div></a></li>';
                                                $('#serviceList').append(html);
                                            }
                                        });
                                        loadCounter = 1;
                                        $('.loading2').hide();
                                        showItems(firstCategory);
                                    });
                                } else {
                                    $("#form2").hide();
                                }
                            });

                            if (typeof service_id !== 'undefined') {
                                createWeeklycalendar(service_id);
                                $('#svn').val(service_id);
                            }

                            $('.close').show();
                            $.ajax({
                                url: baseUrl + "Progressive/website/GetServiceData/service_id/" + service_id + "/city_id/" + localStorage.getItem("geo_city_id"),
                                contentType: "application/json; charset=utf-8",
                                success: function (data) {
                                    var tep = $.parseJSON(data);
                                    //console.log(data);
                                    $('#nab').empty();
                                    $('#nab-con').empty();
                                    $.each(tep, function (index, value) {
                                        //console.log(index + ': ' + value.service_name);
                                        if (value.service_category_name) {
                                            var cat_name = '- ' + value.service_category_name;
                                        }
                                        else {
                                            var cat_name = '';
                                        }
                                        if (service_id != 68) {
                                            $('#city-na').text("- " + localStorage.getItem("geo_city"));
                                        }
                                        //$('#items_title').text(value.service_name+' '+cat_name);

                                        $('#nab').append('<li role="presentation"><a href="#tab' + index + '" aria-controls="tab' + index + '" role="tab" data-toggle="tab">' + value.service_name + ' <span>' + cat_name + '</span></a></li>');
                                        if (index === 0) {
                                            $('#nab-con').append('<div role="tabpanel" class="tab-pane active" id="tab' + index + '"><div class="items_title"><h1 id="items_title">' + value.service_name + ' ' + cat_name + ' </h1><div class="clear"> </div></div></div>');
                                        } else {
                                            $('#nab-con').append('<div role="tabpanel" class="tab-pane" id="tab' + index + '"><div class="items_title"><h1 id="items_title">' + value.service_name + ' ' + cat_name + ' </h1><div class="clear"> </div></div></div>');
                                        }

                                        $.each(value.item, function (a, val) {
                                            //console.log(index + ': ' + val.item_name);
                                            if (val.strike_price > 0) {
                                                $('#tab' + index).append('<div class="items_select"><div class="row"> <div class="col-md-7"> <h3>' + val.item_name + '</h3> </div><div class="col-md-5"> <h2><i class="fa fa-inr"></i> <s>' + val.strike_price + '</s> ' + val.price + '</h2> </div></div></div>');
                                            } else {
                                                var itemDiv = '<div class="items_select"><div class="row"> <div class="col-md-7"> <h3>' + val.item_name + '</h3> </div><div class="col-md-5"> <h2>';
                                                if (!isNaN(val.price)) {
                                                    itemDiv += '<i class="fa fa-inr"></i> ';
                                                }
                                                itemDiv += val.price + '</h2> </div></div></div>';
                                                $('#tab' + index).append(itemDiv);
                                            }
                                        });
                                        $('#tab' + index).append('<div class="rate_text" id="rate_text">' + value.concat_desc + '</div>');


                                        $('.loading').fadeOut();
                                    });
                                }
                            });
                            //End getting services list from Lat & Lng
                        } else {
                            $('#error_geo').text("Sorry, we are currently not serving in your location");
                            $('#error_geo').show();
                            $('#geo_latlon').val("");
                            $('#geo_location1').attr("error-message", "Sorry, we are currently not serving in your location");
                            $("#psuedoLocation").val("");
                            $('#geo_location1').val("");
                            return false;
                        }
                    }
                });
            }
            else {
                $('#error_geo').text("Please select a location from the list");
                $('#error_geo').show();
                return false;
            }
        }
        else {
            $('#error_geo').text("Please select a location from the list");
            $('#error_geo').show();
            return false;
        }

        return false;
    });


    $(document).on('shown.bs.tab', 'a[data-toggle="tab"]', function (e) {
        var currentTab = $(e.target).text();
        rate_card_activity_clicked(currentTab);

    });
});


function showQuesFeedback(qindex, aid) {
    $("#er" + questionsArray[qindex].id).hide();
    if (questionsArray[qindex].answers[aid].feedback != "") {
        $("#msginfo" + qindex).html(questionsArray[qindex].answers[aid].feedback);
        $("#msginfo" + qindex).show();
    } else {
        $("#msginfo" + qindex).hide();
    }
}

function jsAlert() {
    $('#error1').text('Please select a location').show();
}


function checkQuestions() {
    var queArr = [], quesCatAr = [];
    for (var i = 0; i < questionsArray.length; i++) {
        var queString = "";
        if (questionsArray[i].type == 1) {
            if (questionsArray[i].required == 1) {
                if ($('input[name=check' + questionsArray[i].id + ']:checked').val() == "" || $('input[name=check' + questionsArray[i].id + ']:checked').val() == undefined) {
                    //alert("Please select an option for mandatory questions");
                    $("#er" + questionsArray[i].id).show();
                    return false;
                }
            }
            var vall = $('input[name=check' + questionsArray[i].id + ']:checked').val();
            if (drop_location_required === 0) {
                for (var j = 0; j < questionsArray[i].answers.length; j++) {
                    if (questionsArray[i].answers[j].id === vall) {
                        if (questionsArray[i].answers[j].is_drop_location == 2) {
                            drop_location_required = 1;
                        }
                    }
                }
            }
            if (drop_location_same_city === 0) {
                for (var j = 0; j < questionsArray[i].answers.length; j++) {
                    if (questionsArray[i].answers[j].id === vall) {
                        if (questionsArray[i].answers[j].is_same_city == 1) {
                            drop_location_same_city = 1;
                        }
                    }
                }
            }
            if (optionsArray[vall] != 0) {
                quesCatAr.push(optionsArray[vall]);
            }
            queArr.push('{"question_id":' + questionsArray[i].id + ',"answer_type":' + questionsArray[i].type + ',"answer_ids":[' + vall + '],"answer_text":""}');
        } else if (questionsArray[i].type == 2) {
            var vals = [];
            var vall = "";
            $('input[name="check' + questionsArray[i].id + '[]"]').each(function () {
                if (this.checked) {
                    vals.push(this.value);
                    if (optionsArray[this.value] != 0) {
                        quesCatAr.push(optionsArray[this.value]);
                    }
                }
            });
            vall = vals.join(",");
            if (questionsArray[i].required == 1) {
                if (vall == "") {
                    //alert("Please select an option for mandatory questions");
                    $("#er" + questionsArray[i].id).show();
                    return false;
                }
            }
            queArr.push('{"question_id":' + questionsArray[i].id + ',"answer_type":' + questionsArray[i].type + ',"answer_ids":[' + vall + '],"answer_text":""}');
        } else if (questionsArray[i].type == 3) {
            var vall = "";
            if (questionsArray[i].required == 1) {
                if ($('#textarea' + questionsArray[i].id).val() == "") {
                    //alert("Please select an option for mandatory questions");
                    $("#er" + questionsArray[i].id).show();
                    return false;
                }
            }
            val1 = $('#textarea' + questionsArray[i].id).val().toString();
            queArr.push('{"question_id":' + questionsArray[i].id + ',"answer_type":' + questionsArray[i].type + ',"answer_ids":[],"answer_text":"' + val1 + '"}');
        }
    }
    if (drop_location_required === 0) {
        $('#dropLocation1').attr("label", "Enter drop location, skip if same as pickup.");
    }

    queString += "[" + queArr.join(",") + "]";
    $("#quesVal").val(queString);
    $("#actVal").val(quesCatAr.join(","));
    $("#oldActVal").val(quesCatAr[0]);
    $("#form2").hide();
    $("#form3").show();
}

function book_btn() {
    var service = $('#service_name').val();
    book_now_clicked();
    if (service) {

    } else {
        $('#service_error').fadeIn();
        return false;
    }
}

$('.right_scroll').click(function () {

    var item_width = $('.carousel_ul li').outerWidth() + 42;

    var item_length = parseInt($('.carousel_ul li').length) - 7;

    var item_size = '-' + (item_length * 42);

    if (parseInt($('.carousel_ul').css('left').replace('px', '')) <= item_size) {
        return false;
    }

    var left_indent = parseInt($('.carousel_ul').css('left')) - item_width;

    $('.carousel_ul:not(:animated)').animate({'left': left_indent}, 500, function () {

    });
});

$('.left_scroll').click(function () {
    if (parseInt($('.carousel_ul').css('left').replace('px', '')) >= 0) {
        return false;
    }
    var item_width = $('.carousel_ul li').outerWidth() + 42;

    var left_indent = parseInt($('.carousel_ul').css('left')) + item_width;

    $('.carousel_ul:not(:animated)').animate({'left': left_indent}, 500, function () {

    });


});


$('.dateSelect').click(function () {
    $('.dateSelect').removeClass("active");
    $('#dat_error').hide();
    //$(this).addClass("active");
    var givenDate = $(this).attr('data-date');
    $(".dateSelect" + givenDate).addClass("active");
    var splitDate = $(this).attr('data-date').split("-");
    $('#mDate').text(splitDate[2] + ' ' + $(this).attr('data-mon') + ' ' + splitDate[0]);
    $(".surgeButton").hide();
    $('#selectMonth').text($(this).attr('data-mon') + ' ' + $(this).attr('data-year'));
    $('#viewTime').empty();
    $('#viewDate').text(splitDate[2] + ' ' + $(this).attr('data-mon'));
    $('#date1').val($(this).attr('data-date'));
    $('#time1').val('');
    $(".surgeButton").html("");
    $("#surge").hide();
    $(".surgeButton").hide();
    $('#error1').hide();
    sendEnquiry();

    date_clicked();
    gettimeSlot(service_id, 1, 0, givenDate);
});


function MM_jumpMenu(targ, selObj, restore) { //v3.0
    select_service_clicked();
    var val = $('#service_name').val();
    service_selected(val);
    var service_url = selObj.options[selObj.selectedIndex].value;
    if (service_url.indexOf('quikr') === -1) {
        eval(targ + ".location='" + selObj.options[selObj.selectedIndex].value + "'");
    } else {
        window.open(service_url, '_blank');

    }
    if (restore) selObj.selectedIndex = 0;
}

$('#okbutton').click(function () {
    var date = $('#date1').val().length;
    var time = $('#time1').val().length;

    if (date <= 0) {
        $('#dat_error').fadeIn();
        return false;
    }
    else {
        $('#dat_error').fadeOut();
    }
    if (time <= 0) {
        $('#time_error').fadeIn();
        return false;
    }
    $('#error1').hide();
    $('#open_time_date').fadeOut();

    var f = $('#date1').val() + ' ' + $('#time1').val();

    datetimeok_clicked(f);

});


function closeBanner() {
    $("#thirtypersale").hide();
    $("#headerMenu").removeClass("marTop");
}


$('.close_div').click(function () {
    $('#clode').fadeOut();
    $('#form3').show();
    $('#error').hide();
});

$('#discount_apply').click(function () {
    var discount = $('#discount').val().length;
    var phone = $('#phone').val();
    var date = $('#date1').val();
    var time = $('#time1').val();

    if (catAr.indexOf(50) > -1) {
        $('#dis_error').text('Discount cannot be applied on combos.').show();
        $("#itemDivDiscount").remove();
        $("#itemDivTotal").remove();
        $(".price").html(priceVal);

        $("#discount").val("");
        cartDiscountApplied = 0;
        var html = '<div class="items_select2" id="itemDivTotal"><div class="row"><div class="col-md-8"><h3>Total</h3></div><div class="col-md-4"><h2>';
        if (!isNaN(priceVal)) {
            html += '<i class="fa fa-inr"></i> ';
        }
        html += priceVal + '</h2></div></div></div>';
        $("#itemContainer").append(html);
        return false;
    }

    if (discount < 1) {
        $('#dis_error').text('Enter valid discount code').show();
        $("#itemDivDiscount").remove();
        $("#itemDivTotal").remove();
        $(".price").html(priceVal);
        cartDiscountApplied = 0;
        var html = '<div class="items_select2" id="itemDivTotal"><div class="row"><div class="col-md-8"><h3>Total</h3></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> ' + priceVal + '</h2></div></div></div>';
        $("#itemContainer").append(html);
        return false;
    }

    //var da = '{"service_id":"'+service_id+'", "coupon_code": "'+$('#discount').val()+'", "city":"'+localStorage.getItem("geo_city_id")+'", "phone":"'+$('#phone').val()+'", "source":"2"}';
    var da = '{"service_date":"' + date + '","service_time":"' + time + '","service_id":"' + service_id + '", "coupon_code": "' + $('#discount').val() + '", "city":"' + localStorage.getItem("geo_city_id") + '", "phone":"' + $('#phone').val() + '", "source":"2"}';

    $.ajax({
        type: 'POST',
        url: baseUrl + 'front//RejCustomerAppWebService/validateCoupon',
        data: da,
        dataType: 'json',
    }).done(function (data) {
        var re = JSON.stringify(data);
        var rep = JSON.parse(re);
        //console.log(rep.data.message);
        if (rep.data.discount_value != "" && rep.data.errorcode == 0) {
            if (rep.data.discount_type == 0) {
                var pprice = ((priceVal * rep.data.discount_value) / 100).toFixed(0);
                pprice = Math.min(pprice, rep.data.discount_max_value);
            } else {

                var pprice = rep.data.discount_value;
                price = Math.min(pprice, rep.data.discount_max_value);
            }
            var html = '<div class="items_select2" id="itemDivDiscount"><div class="row"><div class="col-md-8"><h3>Discount</h3></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> ' + pprice + '</h2></div></div></div>';
            $("#itemDivDiscount").remove();
            $("#itemDivTotal").before(html);
            $("#itemDivTotal").remove();
            cartDiscountApplied = 1;
            $(".price").html(priceVal - pprice);
            var html = '<div class="items_select2" id="itemDivTotal"><div class="row"><div class="col-md-8"><h3>Total</h3></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> ' + (priceVal - pprice) + '</h2></div></div></div>';
            $("#itemContainer").append(html);
        } else if (rep.data.errorcode != 0) {
            $("#itemDivDiscount").remove();
            $("#itemDivTotal").remove();
            $(".price").html(priceVal);
            cartDiscountApplied = 0;
            var html = '<div class="items_select2" id="itemDivTotal"><div class="row"><div class="col-md-8"><h3>Total</h3></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> ' + priceVal + '</h2></div></div></div>';
            $("#itemContainer").append(html);
        }
        $('#dis_error').text(rep.data.message).show();
        apply_coupon_clicked(rep.data.message);
    });


});


$('#processStep1').click(function () {

    if (service_id == 68) {
        var dateFix = new Date();
        var tomorrow = new Date();
        tomorrow.setDate(dateFix.getDate() + 1);
        var day = tomorrow.getDate();
        if (parseInt(day) < 10) {
            day = '0' + parseInt(day);
        }
        var month = tomorrow.getMonth() + 1;
        if (parseInt(month) < 10) {
            month = '0' + parseInt(month);
        }
        var year = tomorrow.getFullYear();
        var dateNew = year + "-" + month + "-" + day;
        $('#date1').val(dateNew);
        $('#time1').val('12 : 00 : PM');
        $("#textarea6").val($("#dropLocation").val());
        $("#textarea8").val($("#pickupLocation").val());
        $("#textareasection6").hide();
        $("#textareasection8").hide();
    }

    var date = $('#date1').val().length;
    var time = $('#time1').val().length;
    var name = $('#fname').val().trim().length;
    var mobile = $('#phone').val().trim().length;
    var mob = $('#phone').val();


    if (date < 1 || time < 1) {
        $('#error1').text('Please select date & time').show();
        return false;
    }

    if (name < 1) {
        $('#fname').val('');
    }

    if (mobile < 10 || mobile > 10) {
        $('#phone').attr('invalid', '');
        return false;
    }

    var fname = document.getElementById('fname').validate();
    var email = document.getElementById('email').validate();
    var phone = document.getElementById('phone').validate();


    if (service_id == 68) {
        var pickup = document.getElementById('pickupLocation').validate();
        var drop = document.getElementById('dropLocation').validate();
        if (fname === false || email === false || phone === false || pickup === false || drop === false) {
            return false;
        }
    }


    if (fname === false || email === false || phone === false) {

        return false;
    }
    $("#service_value").val(service_id);


    $('#form1').hide();
    $("#displayTime").val("Service Time: " + $("#mDate").html() + "" + $("#mtime").html());
    /*if(loadCounter==0){
     $('.loading2').show();
     }*/
    if ($("#cart_type").html() == 0 && questionsArray.length == 0) {
        $(".loading2").hide();
        $('#form3').show();
    } else {
        $('#form2').show();
    }

    if (service_id == 68) {
        if (leadCounter == 0) {
            sendEnquiry();
        }
    }

    proceed_clicked();
});


function sendEnquiry() {
    var fname = document.getElementById('fname').value;
    var email = document.getElementById('email').value;
    var phone = document.getElementById('phone').value;
    if (fname == "" || email == "" || phone == "") {

    } else {
        if (leadCounter == 0) {
            /* <![CDATA[ */
            goog_snippet_vars = function () {

                var google_conversion_id = 874438451;
                var google_conversion_language = "en";
                var google_conversion_format = "3";
                var google_conversion_color = "ffffff";
                var google_conversion_label = "VIChCPWHj2wQs777oAM";
                var google_remarketing_only = false;
            }
// DO NOT CHANGE THE CODE BELOW.
            goog_report_conversion = function (url) {
                goog_snippet_vars();
                window.google_conversion_format = "3";
                var opt = new Object();
                opt.onload_callback = function () {
                    if (typeof(url) != 'undefined') {
                        window.location = url;
                    }
                }
                var conv_handler = window['google_trackConversion'];
                if (typeof(conv_handler) == 'function') {
                    conv_handler(opt);
                }
            }
            /* ]]> */
            leadCounter = 1;
            $("#enquiryName").val($('#fname').val());
            $("#enquiryEmail").val($('#email').val());
            $("#enquiryPhone").val($('#phone').val());
            $("#enquiryServices").val(service_id);
            var datastring = $('#bookingForm').serialize();
            $.ajax({
                type: 'POST',
                url: baseUrl + 'front//front/enquiry',
                data: datastring,
                success: function (result) {
                    <!-- Facebook Conversion Code for Facebook Pixel - NEW -->
                    (function () {
                        var _fbq = window._fbq || (window._fbq = []);
                        if (!_fbq.loaded) {
                            var fbds = document.createElement('script');
                            fbds.async = true;
                            fbds.src = 'https://connect.facebook.net/en_US/fbds.js';
                            var s = document.getElementsByTagName('script')[0];
                            s.parentNode.insertBefore(fbds, s);
                            _fbq.loaded = true;
                        }
                    })();
                    window._fbq = window._fbq || [];
                    window._fbq.push(['track', '6047943173670',
                        {'value': '0.00', 'currency': 'INR'}
                    ]);
                    <!-- Facebook Conversion Code for Facebook Pixel - NEW -->

                    var cityName = !!(localStorage.getItem("geo_city")) ? localStorage.getItem("geo_city") : '';
                    fbq('track', 'Lead', {
                            content_type: 'product',
                            Page_type: "LEAD_PAGE",
                            Category_Name: localStorage.getItem("serviceName"),
                            SubCategory_Name: '',
                            USER_CITY_NAME: cityName
                        }
                    );
                    // GOOGLE CONVERSION CODE: SALE LEAD
                    var LEAD_CONVERSION_ATTRS = {
                        google_conversion_id: 874438451,
                        google_conversion_language: "en",
                        google_conversion_format: "3",
                        google_conversion_color: "ffffff",
                        google_conversion_label: "-aUtCP2FvG8Qs777oAM",
                        google_remarketing_only: false
                    };
                    var LEAD_CONVERSION_ATTR = {
                        google_conversion_id: 863952810,
                        google_conversion_language: "en",
                        google_conversion_format: "3",
                        google_conversion_color: "ffffff",
                        google_conversion_label: "S08TCIb_1nIQqr_7mwM",
                        google_remarketing_only: false
                    };
                    try {
                        window.google_trackConversion(LEAD_CONVERSION_ATTRS);
                        window.google_trackConversion(LEAD_CONVERSION_ATTR);
                    } catch (e) {
                        console.log('Google Lead Conversion Failed:', e);
                    }

                    /* ********* GOOGLE REMARKETING TAG ******** */
                    var customParams = {
                        dynx_itemid: service_id,
                        dynx_pagetype: 'LEAD_PAGE'
                    };
                    window.google_trackConversion({
                        google_conversion_id: 863965580,
                        google_custom_params: customParams,
                        google_remarketing_only: true
                    });
                    /* ********* GOOGLE REMARKETING TAG ******** */


                },
                error: function () {
                    console.log("Enquiry failed");
                }
            });
        }
    }
}

$('#bookingStep').click(function () {
    book_now_clicked();
    var book = 'bookingStep';
    var form = 'bookingForm';
    var address = document.getElementById('flat_no').validate();
    var droplocation = $('#dropLocation1').val();
    var geo_lat_drop = $('#geo_lat_drop').val();
    var geo_lon_drop = $('#geo_lon_drop').val();
    var geo_loc_name_drop = $('#geo_loc_name_drop').val();

    if (drop_location_required === 1 && (geo_loc_name_drop == '' || $('#geo_loc_name_drop').length === 0)) {
        $('#dropLocation1').attr('invalid', '');
        $('#dropLocation1').attr("error-message", "Please enter a location");
        return false;
    }
    if (geo_loc_name_drop != '' && (droplocation != geo_loc_name_drop)) {
        $('#dropLocation1').attr('invalid', '');
        return false;
    }


    if ($('#displayActivity').length) {
        var displayActivity = $('#displayActivity').val();
        if (displayActivity == "") {
            $("#error2").show();
            return false;
        }
    }


    if (questionsArray.length == 0) {
        var itemQ = '{';
        var itemQarray = [];
        for (var i = 0; i < itemAr.length; i++) {
            itemQ += '"' + itemAr[i] + '":"' + itArr[itemAr[i]] + '",';
            var itemQjson = '{"itemId":' + itemAr[i] + ', "itemQuantity": ' + itArr[itemAr[i]] + '}';
            itemQarray.push(JSON.parse(itemQjson));

        }
        $("#itemVal").val(itemAr.join(","));
        $("#actVal").val(catAr.join(","));
        if (itemQ != "{") {
            itemQ = itemQ.substring(0, itemQ.length - 1);
            itemQ += '}';
        } else {
            itemQ = '';
        }
        $("#itemQ").val(itemQ);
    } else {
        var itemQarray = "";
    }
    if (address === false) {
        return false;
    }
    //if(droplocation == false){
    //    return false;
    //}
    $('.loading2').show();
    $('.items_title').hide();
    $('#load_submit').show();
    var datastring = $('#bookingForm').serialize();
//ashishbooking

    if ($("#cartPrice").val() === '') {
        var cartPrice = 0;
    } else {
        var cartPrice = $("#cartPrice").val();
    }
    var order_book = {};
    order_book['sourceId'] = "12";
    order_book['city'] = $("#city").val();
    order_book['latitude'] = $("#geo_lat").val();
    order_book['longitude'] = $("#geo_lon").val();
    order_book['geo_loc_name'] = $("#geo_loc_name").val();
    order_book['geo_location'] = $("#geo_loc_name").val();
    order_book['drop_location_lat'] = $("#geo_lat_drop").val();
    order_book['drop_location_lng'] = $("#geo_lon_drop").val();
    order_book['drop_location'] = $("#geo_loc_name_drop").val();
    order_book['serviceDate'] = $("#date1").val();
    order_book['serviceTime'] = $("#time1").val();
    order_book['building_society'] = '';
    order_book['flat_no'] = $("input[name=flat_no]").val();
    order_book['building_name'] = $("input[name=flat_no]").val();
    order_book['landmark'] = $("input[name=landmark]").val();
    order_book['couponCode'] = $("#discount").val();
    order_book['sur_pr'] = $("#sur_pr").val();
    order_book['serviceId'] = $("#service_id_value").val();
    order_book['activity'] = $("#actVal").val();
    order_book['item'] = $("#itemVal").val();
    order_book['cartItems'] = itemQarray;
    order_book['item_qty'] = $("#itemQ").val();
    order_book['cartTotalPrice'] = cartPrice;
    if ($("#quesVal").val() == '') {
        order_book['questions'] = [];
    } else {
        order_book['questions'] = JSON.parse($("#quesVal").val());
    }
    order_book['utm_source'] = $("#utm_source").val();
    order_book['utm_content'] = $("#utm_content").val();
    order_book['utm_medium'] = $("#utm_medium").val();
    order_book['utm_term'] = $("#utm_term").val();
    order_book['utm_campaign'] = $("#utm_campaign").val();
    order_book['fname'] = $("#fname").val();
    order_book['lname'] = '';
    order_book['email'] = $("#email").val();
    order_book['customerphone'] = $("#phone").val();
    order_book['phone_no'] = $("#phone").val();

    //var datastring = $('#'+form).serialize();

    $.ajax({
        type: 'POST',
        "url": baseUrl + "front/RejCustomerAppWebService/OrderBooking",
        data: {'data': JSON.stringify(order_book)},
        //data: datastring,
        success: function (result) {
            var rep = JSON.parse(result);
            goog_report_conversion();
            (function () {
                var _fbq = window._fbq || (window._fbq = []);
                if (!_fbq.loaded) {
                    var fbds = document.createElement('script');
                    fbds.async = true;
                    fbds.src = '//connect.facebook.net/en_US/fbds.js';
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(fbds, s);
                    _fbq.loaded = true;
                }
            })();
            window._fbq = window._fbq || [];
            window._fbq.push(['track', '6023650819336', {'value': '0.00', 'currency': 'INR'}]);
            (function () {
                var _fbq = window._fbq || (window._fbq = []);
                if (!_fbq.loaded) {
                    var fbds = document.createElement('script');
                    fbds.async = true;
                    fbds.src = '//connect.facebook.net/en_US/fbds.js';
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(fbds, s);
                    _fbq.loaded = true;
                }
            })();
            window._fbq = window._fbq || [];
            window._fbq.push(['track', '1493484774284573', {'value': '0.00', 'currency': 'INR'}]);


            // GOOGLE CONVERSION CODE: BOOKING
            var BOOKING_CONVERSION_ATTRS = {
                google_conversion_id: 874438451,
                google_conversion_language: "en",
                google_conversion_format: "3",
                google_conversion_color: "ffffff",
                google_conversion_label: "SHB9COr8tW8Qs777oAM",
                google_remarketing_only: false
            };
            try {
                window.google_trackConversion(BOOKING_CONVERSION_ATTRS);
            } catch (e) {
                console.log('Google Lead Conversion Failed:', e);
            }

            if (/utm_source=facebook/.test(window.location.search) && typeof window.fbq === 'function') {
                window.fbq('track', 'InitiateCheckout');
            }

            if (localStorage.getItem("log_ph")) {
                mixpanel.identify(localStorage.getItem("log_ph"));
            } else {
                mixpanel.identify($('#phone').val());
            }
            mixpanel.track(
                "Order",
                {
                    "service_name booked": localStorage.getItem("serviceName"),
                    "Order Phone": $('#phone').val(),
                    "Label": $('#pincode').val(),
                    "First Name": $('#fname').val(),
                    "Last Name": $('#lname').val(),
                    "Action": "Address - " + $('input[name=flat_no]').val(),
                    "Landmark": $('input[name=landmark]').val(),
                    "Category": "Service By Location - " + localStorage.getItem("city")
                }
            );
            localStorage.setItem("fname_c", $('#' + form + ' #fname').val());
            localStorage.setItem("lname_c", $('#' + form + ' #lname').val());
            localStorage.setItem("phone_c", $('#' + form + ' #phone').val());
            localStorage.setItem("email_c", $('#' + form + ' #email').val());
            localStorage.setItem("address_c", $('#' + form + ' input[name=flat_no]').val());
            localStorage.setItem("landmark_c", $('#' + form + ' input[name=landmark]').val());
            localStorage.setItem("loc_c", $('#' + form + ' #Customer_locality').val());
            var ser = result.split("|");

            if (rep.data.errorcode == 0 && rep.data.NewCustomer == 1) {
                //alert(ser[2]);
                $('#load_submit').hide();
                $('.OTP').show();
                $('#cd-otp').show();
                $('#booking_id').val(rep.data.checkout.booking_id);
                $('#job_id').val(rep.data.checkout.job_id);
                mixpanel.track(
                    "Order Status", {
                        "Action": "Order partially placed - Cancel",
                        "Category": "Order",
                    }
                );
            }
            if (rep.data.errorcode == 0 && rep.data.NewCustomer != 1) {
                booking_successful();
                var locationstring = window.location.href.split("?");
                if (locationstring[1]) {
                    window.location = '/order-thank-you?ordid=' + rep.data.checkout.job_id + '&' + locationstring[1];
                } else {
                    window.location = '/order-thank-you?ordid=' + rep.data.checkout.job_id;
                }

            }
            /* Mukesh / Ashish for Coupon Validation for user level on 18-10-2015 start here*/
            if (rep.data.errorcode != 0) {
                $('#load_submit').hide();
                $('#error').show();
                $('#form3').hide();
                $('#error p').text(rep.data.message);
                booking_unsuccessful();
                return false;
            }

            //if (ser[0] == '5') {
            //    $('#load_submit').hide();
            //    $('#error').show();
            //    $('#error p').text("Sorry due to technical issue your close_div has not been placed. Please Try Again");
            //    booking_unsuccessful();
            //    return false;
            //}
        },
        error: function () {
            $('#error p').text("Sorry due to technical issue your order has not been placed. Please Try Again");
            booking_unsuccessful();
            return false;
        }
    });

    // $('#form1').hide();
    // $('#form2').show();
});

$('#backStep1').click(function () {
    $('#form2').hide();
    $('#form1').show();
});

$('#backStep2').click(function () {
    $('#open_time_date').hide();
});

cal_days_labels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

cal_months_labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function showItems(category_id) {
    var accordianhtml = "", itemhtml = "", accordianhtmlBack = "";
    var counter = 0;
    $(".lists_card_title").html($("#val" + category_id).html());
    if (itemArray[category_id]['subcatcheck'] == 1) {
        var html = '<div class="panel-group" id="accordion4"><div role="tabpanel" class="tab-pane active" id="salon_tab_' + category_id + '">';
        $("#tab_content").html(html);
        for (var j = 0; j < itemArray[category_id]['subcatcheckValue'].length; j++) {
            accordianhtml = '<div class="panel panel-default"><div class="panel-heading salon_heading" data-toggle="collapse" data-parent="#accordion4" href="#waxing' + (j + 1) + '"><h4 class="panel-title"><a class="accordion-toggle">' + itemArray[category_id]['subcatcheckValue'][j] + '</a><i class="indicator fa fa-angle-down pull-right"></i></h4></div><div id="waxing' + (j + 1) + '" class="panel-collapse collapse">';
            itemhtml = '<div class="panel-body">';
            var i = 0;
            for (var item in itemArray[category_id]) {
                if (!isNaN(item) && itemArray[category_id]['subcatcheckValue'][j] == itemArray[category_id][item].subcategory_name) {
                    if (itemArray[category_id][item].strike_price > 0) {
                        itemhtml += '<div class="items_salon"><div class="row"><div class="col-md-8"><h3>' + itemArray[category_id][item].item_name + '</h3><p>' + itemArray[category_id][item].item_desc + '</p></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> <s>' + itemArray[category_id][item].strike_price + '</s> ' + itemArray[category_id][item].price + '</h2>';
                    } else {
                        itemhtml += '<div class="items_salon"><div class="row"><div class="col-md-8"><h3>' + itemArray[category_id][item].item_name + '</h3><p>' + itemArray[category_id][item].item_desc + '</p></div><div class="col-md-4"><h2>';
                        if (!isNaN(itemArray[category_id][item].price)) {
                            if (!isNaN(itemArray[category_id][item].display_price)) {
                                itemhtml += '<i class="fa fa-inr"></i> ';
                            }
                        }

                        if (itemArray[category_id][item].display_price == "undefined" || isNaN(itemArray[category_id][item].display_price)) {
                            itemhtml += itemArray[category_id][item].display_price + '</h2>';
                        } else {
                            itemhtml += itemArray[category_id][item].price + '</h2>';
                        }
                    }

                    if ($("#cart_type").html() == 1) {
                        if (itArr[item] == 0) {
                            itemhtml += '<span><input id="check' + item + '_' + category_id + '" type="checkbox" name="check" value="check' + item + '_' + category_id + '" onclick="selectItem(' + item + ',' + category_id + ',0)"><label for="check' + item + '_' + category_id + '"></label></span>';
                        } else {
                            itemhtml += '<span><input id="check' + item + '_' + category_id + '" checked type="checkbox" name="check" value="check' + item + '_' + category_id + '" onclick="selectItem(' + item + ',' + category_id + ',0)"><label for="check' + item + '_' + category_id + '"></label></span>';
                        }
                        i++;
                    } else if ($("#cart_type").html() == 2) {
                        itemhtml += '<span><a onclick="selectItem(' + item + ',' + category_id + ',1)"><i class="fa fa-minus-circle"></i></a> <small class="item' + item + '">' + itArr[item] + '</small> <a onclick="selectItem(' + item + ',' + category_id + ',2)"><i class="fa fa-plus-circle"></i></a></span>';
                    }
                    itemhtml += '</div></div></div>';
                }
            }
            itemhtml += '</div>';
            accordianhtmlBack = '</div></div>';
            var html = accordianhtml + itemhtml + accordianhtmlBack;
            $("#tab_content").append(html);
        }
        html = '</div>';
        $("#tab_content").append(html);

    }
    else {
        itemhtml = '<div class="panel-body">';
        var i = 0;
        for (var item in itemArray[category_id]) {
            if (!isNaN(item)) {
                if (itemArray[category_id][item].strike_price > 0) {
                    itemhtml += '<div class="items_salon"><div class="row"><div class="col-md-8"><h3>' + itemArray[category_id][item].item_name + '</h3><p>' + itemArray[category_id][item].item_desc + '</p></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> <s>' + itemArray[category_id][item].strike_price + '</s> ' + itemArray[category_id][item].price + '</h2>';
                } else {
                    itemhtml += '<div class="items_salon"><div class="row"><div class="col-md-8"><h3>' + itemArray[category_id][item].item_name + '</h3><p>' + itemArray[category_id][item].item_desc + '</p></div><div class="col-md-4"><h2>';
                    if (!isNaN(itemArray[category_id][item].price)) {
                        if (!isNaN(itemArray[category_id][item].display_price)) {
                            itemhtml += '<i class="fa fa-inr"></i> ';
                        }
                    }
                    if (itemArray[category_id][item].display_price == "undefined" || isNaN(itemArray[category_id][item].display_price)) {
                        itemhtml += itemArray[category_id][item].display_price + '</h2>';
                    } else {
                        itemhtml += itemArray[category_id][item].price + '</h2>';
                    }

                }

                if ($("#cart_type").html() == 1) {
                    if (itArr[item] == 0) {
                        itemhtml += '<span><input id="check' + item + '_' + category_id + '" type="checkbox" name="check" value="check' + item + '_' + category_id + '" onclick="selectItem(' + item + ',' + category_id + ',0)"><label for="check' + item + '_' + category_id + '"></label></span>';
                    } else {
                        itemhtml += '<span><input id="check' + item + '_' + category_id + '" checked type="checkbox" name="check" value="check' + item + '_' + category_id + '" onclick="selectItem(' + item + ',' + category_id + ',0)"><label for="check' + item + '_' + category_id + '"></label></span>';
                    }
                    i++;
                } else if ($("#cart_type").html() == 2) {
                    itemhtml += '<span><a onclick="selectItem(' + item + ',' + category_id + ',1)"><i class="fa fa-minus-circle"></i></a><small class="item' + item + '">' + itArr[item] + '</small><a onclick="selectItem(' + item + ',' + category_id + ',2)"><i class="fa fa-plus-circle"></i></a></span>';
                }
                itemhtml += '</div></div></div>';
            }
        }
        itemhtml += '</div>';
        var html = '<div role="tabpanel" class="tab-pane active" id="salon_tab_' + category_id + '">' + itemhtml + '</div>';
        $("#tab_content").html(html);
    }
}

function selectItem(item_id, category_id, val) {
    $("#erm").hide();
    if (catAr.indexOf(category_id) == -1) {
        catAr.push(category_id);
    }
    if (itemAr.indexOf(item_id) == -1) {
        itemAr.push(item_id);
    }
    itemArray[category_id][item_id].display_price = '';
    if (isNaN(itemArray[category_id][item_id].price)) {
        itemArray[category_id][item_id].price = 0;
        itemArray[category_id][item_id].display_price = 'On Inspection';
        blockCounter = 1;
    }
    if (val == 0) {
        if (itArr[item_id] == 0) {
            itArr[item_id] = 1;
            itemTotal++;
            price += parseInt(itemArray[category_id][item_id].price);
        } else {
            itArr[item_id] = 0;
            itemTotal--;
            itemAr.splice(itemAr.indexOf(item_id), 1);
            price -= parseInt(itemArray[category_id][item_id].price);
        }
    } else if (val == 1) {
        itArr[item_id]--;
        itemTotal--;
        price -= parseInt(itemArray[category_id][item_id].price);
        if (itArr[item_id] < 0) {
            itArr[item_id]++;
            itemTotal++;
            price += parseInt(itemArray[category_id][item_id].price);
        } else if (itArr[item_id] == 0) {
            itemAr.splice(itemAr.indexOf(item_id), 1);
        }
        $(".item" + item_id).html(itArr[item_id]);
    } else if (val == 2) {
        itArr[item_id]++;
        itemTotal++;
        price += parseInt(itemArray[category_id][item_id].price);
        if (itArr[item_id] > itemArray[category_id][item_id].max_quantity && itemArray[category_id][item_id].max_quantity != 0) {
            itemTotal--;
            price -= parseInt(itemArray[category_id][item_id].price);
        }
        $(".item" + item_id).html(itArr[item_id]);
    }
    var minPrice = $("#minP").val();
    var insPrice = $("#insP").val();

    if (parseInt(itemTotal) == 0) {
        priceVal = 0;
    } else if (minPrice > price) {
        priceVal = minPrice;
    } else {
        priceVal = price;
    }
    $(".price").html(priceVal);
    $("#cartPrice").val(priceVal);
    $(".items").html("(" + itemTotal + " Items)");
    var catName = $('.lists_card_title').html();
    if (itemArray[category_id][item_id].subcategory_name === undefined || itemArray[category_id][item_id].subcategory_name === null) {
        var subcatName = "";
    } else {
        var subcatName = "-" + itemArray[category_id][item_id].subcategory_name;
    }

    var html = '<div class="items_select2" id="itemDiv' + item_id + '"><div class="row"><div class="col-md-8"><h3>' + itemArray[category_id][item_id].item_name + '<span>x ' + itArr[item_id] + '</span></h3><br/><p>' + catName + subcatName + '</p></div><div class="col-md-4"><h2>';
    if (!isNaN(itArr[item_id] * itemArray[category_id][item_id].price)) {
        html += '<i class="fa fa-inr"></i> ';
    }
    html += (itArr[item_id] * itemArray[category_id][item_id].price) + '</h2></div></div></div>';
    $("#itemDiv" + item_id).remove();
    if (itArr[item_id] != 0) {
        $("#itemContainer").append(html);
    }
    $("#itemDivMin").remove();
    if (minPrice > price) {
        var priceDiff = minPrice - price;
        var html = '<div class="items_select2" id="itemDivMin"><div class="row"><div class="col-md-8"><h3>Minimum Charge Adjustment</h3><br/><p>*Inspection Charges : Rs.' + insPrice + '</p></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> ' + priceDiff + '</h2></div></div></div>';
        $("#itemContainer").append(html);
    }
    $("#itemDivTotal").remove();
    var html = '<div class="items_select2" id="itemDivTotal"><div class="row"><div class="col-md-8"><h3>Total</h3></div><div class="col-md-4"><h2><i class="fa fa-inr"></i> ' + priceVal + '</h2></div></div></div>';
    $("#itemContainer").append(html);
    fbq('track', 'InitiateCheckout', {
        content_type: 'product',
        Page_type: "CART_PAGE",
        Category_Name: localStorage.getItem("serviceName"),
        SubCategory_Name: '',
        USER_CITY_NAME: cityName
    });

}

function showAddress() {
    if (itemAr.length == 0) {
        //alert("Please select atleast one service!");
        $("#erm").html("Please select atleast one service!").show();
        return false;
    }
    if ($("#minP").val() > priceVal && blockCounter == 0) {
        $("#erm").html("Your cart value cannot be less than " + $("#minP").val()).show();
        return false;
    }
    $("#form2").hide();
    $("#form3").show();
}

function editActivity() {
    $("#itemDivDiscount").remove();
    $("#form2").show();
    $("#form3").hide();
}

function createWeeklycalendar(a) {
    var geo_lat = localStorage.getItem("geo_lat");
    var geo_lon = localStorage.getItem("geo_lon");
    var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "service_id": ' + a + '}';
    $('.carousel_ul').html("");
    var response = $.ajax({
        type: 'POST',
        url: '//api.zimmber.com/timeslots/v2/getTimeSlots',
        //url: '//apitest.zimmber.com/timeslots/v2/getTimeSlots',
        data: {data: da},
        dataType: 'json',
        success: function (data) {
            var jdate = data.minDate;
            var json_time = data.minTime;
            var json_sdm = data.slotDuration;
            var durationTime = ISOcoverttime(json_sdm);
            var jtime = json_time.split(":");
            if (jtime[2].trim() == "PM" && jtime[0] != 12) {
                jtime[0] = parseInt(jtime[0]) + 12;
            } else {
                jtime[0] = parseInt(jtime[0]);
            }
            jtime[1] = parseInt(jtime[1]);
            var days = ISOcovertdate(data.maxPeriod) - 1;

            var from = jdate.split("-");
            var date = new Date(from[0], from[1] - 1, from[2]);
            var fday = date.getDate();
            var tdate = new Date();
            var tday = tdate.getDate();

            if (durationTime >= 60) {
                if (jtime[1] != 0) {
                    jtime[1] = "00";
                    jtime[0] = jtime[0] + 1;
                }
            } else {
                var varience = jtime[1] % durationTime;
                jtime[1] = jtime[1] - varience + durationTime;
                if (jtime[1] == 60) {
                    jtime[1] = "00";
                    jtime[0] = jtime[0] + 1;
                }
            }
            //var then = jdate+" "+jtime[0]+":"+jtime[1]+":00";
            var thenDate = new Date(from[0], from[1] - 1, from[2], jtime[0], jtime[1]);

            var minShow = thenDate.getMinutes() - tdate.getMinutes();
            var hourShow = thenDate.getHours() - tdate.getHours();
            if (minShow < 0) {
                minShow = 60 + minShow;
                hourShow = hourShow - 1;
            }

            if (minShow == 0) {
                $(".boxElement").html("Available in " + hourShow + " hours");
            } else if (hourShow == 0) {
                $(".boxElement").html("Available in " + minShow + " minutes");
            } else if (hourShow == 1) {
                $(".boxElement").html("Available in " + hourShow + " hour " + minShow + " minutes");
            } else {
                $(".boxElement").html("Available in " + hourShow + " hours " + minShow + " minutes");
            }

            $(".boxElement").show();
            if (fday != tday) {
                $(".boxElement").hide();
            }
            if (hourShow >= 3) {
                $(".boxElement").hide();
            }
            /*var date = new Date();*/
            var year = date.getFullYear();
            var month = cal_months_labels[date.getMonth()];
            $('#selectMonth').text(month + ' ' + year);
            var i = 0;
            var zero = (date.getMonth() < 9) ? "0" : "";
            var zeros = (date.getDate() < 10) ? "0" : "";

            var dateMsg = date.getFullYear() + '-' + zero + (date.getMonth() + 1) + '-' + zeros + date.getDate();

            $('.carousel_ul').append('<li><a href="javascript:;" class="dateSelect dateSelect' + dateMsg + '" data-date="' + dateMsg + '" data-mon="' + month + '" data-year="' + year + '">' + cal_days_labels[date.getDay()] + '<br/><span>' + date.getDate() + '</span></a></li>');
            for (i = 0; i < days; i++) {
                date.setDate(date.getDate() + 1);
                var zero = (date.getMonth() < 9) ? "0" : "";
                var zeros = (date.getDate() < 10) ? "0" : "";

                var dateMsg = date.getFullYear() + '-' + zero + (date.getMonth() + 1) + '-' + zeros + date.getDate();
                var months = cal_months_labels[date.getMonth()];
                //if(date.getMonth() == 6 && date.getDate() == 6){} else {
                $('.carousel_ul').append('<li><a href="javascript:;" class="dateSelect dateSelect' + dateMsg + '" data-date="' + dateMsg + '" data-mon="' + months + '"  data-year="' + date.getFullYear() + '">' + cal_days_labels[date.getDay()] + '<br/><span>' + date.getDate() + '</span></a></li>');
                //}
            }
            $('.dateSelect').click(function () {
                $('.dateSelect').removeClass("active");
                $('#dat_error').hide();
                $('#error1').hide();
                var givenDate = $(this).attr('data-date');
                $(".dateSelect" + givenDate).addClass("active");
                var splitDate = $(this).attr('data-date').split("-");
                $('#mDate').text(splitDate[2] + ' ' + $(this).attr('data-mon') + ' ' + splitDate[0]);
                $('#viewDate').text(splitDate[2] + ' ' + $(this).attr('data-mon'));
                $('#date1').val($(this).attr('data-date'));
                $('#selectMonth').text($(this).attr('data-mon') + ' ' + $(this).attr('data-year'));
                $('#viewTime').empty();
                $('#time1').val('');
                $(".surgeButton").html("");
                $("#surge").hide();
                $(".surgeButton").hide();
                sendEnquiry();
                date_selected();
                gettimeSlot(service_id, 1, 0, givenDate);
            });


        }
    });
}

function serviceSet(a) {
    //Created by sagar bangar on 08-10-2015 for get Service
    $.get(baseUrl + "Progressive/web/m_getservices/city/" + a, function (data) {
        $("#service_name").html(data);
        $("#service_namesub").html(data);
        if (typeof service_id !== 'undefined') {
            $("select#service_name").val(service_id);
            service_onchange();
            $("select#service_namesub").val(service_id);
        }
    });
}

function service_onchange() {
    $('#delivery').hide();
    $('#delivery1').hide();
    $('#title1').text('When & Where');
    $('#title2').text('When & Where');
    var service_name = $("#service_name").val();
    var city = $("#city").val();
    $('#form1 #svn').val(service_name);
    $('#form2 #svn').val(service_name);
    $("#date1").val('');
    $("#timepicker1").val('');
    if (service_name) {
        var valid_date = $('#service_name').find(':selected').attr("data-d");
        var val_d = parseInt(valid_date);
        //console.log(val_d);
        getdate(val_d, service_name);
        $('#morning1').empty();
        $('#afternoon1').empty();
        $('#evening1').empty();
        $("#book_price").load("/mobile/pricetbw.php?is=" + service_name + "&ci=" + city + "&ke=1");
        if (service_name === "54") {
            $('#delivery').show();
            $('#title1').text('Pickup Date & time');
        }
    }
    if (service_name == 54 || service_name == 55) {
        $.ajax({
            type: 'POST',
            url: baseUrl + "Progressive/web/get_activity",
            data: 'service_id=' + service_name,
            success: function (result) {
                $('#display_activity').show();
                $('#activity_name').html(result);
            }
        });
    } else {
        $('#display_activity').hide();
    }
}


function serviceSet1(a) {

}

function noHoilday(date) {
    var day = date.getDay();
    var ndate = new Date("March 24, 2016");
    var fdate = new Date(date.getYear(), date.getMonth(), date.getDate());
    //console.log(fdate);
    if (date.getDate() == ndate.getDate() && date.getMonth() == ndate.getMonth() && date.getYear() == ndate.getYear()) {
        return [false];
        //console.log(fdate);
    }
    else {
        return [true];
    }
};

function noSunday(date) {
    var day = date.getDay();
    var ndate = new Date("March 24, 2016");
    var fdate = new Date(date.getYear(), date.getMonth(), date.getDate());
    //console.log(fdate);
    if (date.getDate() == ndate.getDate() && date.getMonth() == ndate.getMonth() && date.getYear() == ndate.getYear()) {
        return [false];
        //console.log(fdate);
    }

    else {
        return [(day > 0), ''];
    }
};

function ISOcovertdate(duration) {
    var match = duration.match(/P(\d+D)?/)

    var day = (parseInt(match[1]) || 0);

    return day;
}

function getdate(dda, a) {
    var geo_lat = localStorage.getItem("geo_lat");
    var geo_lon = localStorage.getItem("geo_lon");
    var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "service_id": ' + a + '}';
    var response = $.ajax({
        type: 'POST',
        url: '//api.zimmber.com/timeslots/v2/getTimeSlots',
        //url: '//apitest.zimmber.com/timeslots/v2/getTimeSlots',
        data: {data: da},
        dataType: 'json',
        success: function (data) {
            var jdate = data.minDate;
            var maxdate = ISOcovertdate(data.maxPeriod);
            var deldate = maxdate + 3;

            $('#date1').datepicker('destroy');
            $('#date2').datepicker('destroy');
            if (dda) {
                var da = dda;
            } else {
                var da = 0;
            }

            if (da === 1) {
                var date = new Date();
                var timerw = date.getHours();
                // console.log(timerw);
                if (timerw > 18) {
                    var de = da + 1;
                    // console.log(de);
                } else {
                    var de = da;
                }
            } else {
                var de = da;
            }
            if (a == 54) {

                $("#date1").datepicker({
                    dateFormat: "yy-mm-dd",
                    minDate: jdate,
                    maxDate: maxdate,
                    beforeShowDay: noSunday,
                    onSelect: function (date) {
                        var city = $("#citysub").val();
                        var service_name = $("#service_name").val();
                        $('#error1').hide();
                        $('#timepicker1').text('Select Time');
                        $('#time1').val('');
                        $('#form1 #svn').val(service_name);
                        var date2 = $('#date1').datepicker('getDate');
                        if (date2.getDay() === 4) {
                            date2.setDate(date2.getDate() + 4);
                        }
                        else {
                            date2.setDate(date2.getDate() + 3);
                        }
                        gettimeSlot(service_name, 1, city, $('#date1').datepicker('getDate'));
                        $('#date11').datepicker('setDate', date2);
                        //sets minDate to dt1 date + 1
                        $('#date11').datepicker('option', 'minDate', date2);
                    }
                });

                $("#date11").datepicker({
                    dateFormat: "yy-mm-dd",
                    minDate: 3,
                    maxDate: deldate,
                    beforeShowDay: noSunday,
                    onClose: function () {
                        var dt1 = $('#date1').datepicker('getDate');
                        //console.log(dt1);
                        var dt2 = $('#date11').datepicker('getDate');
                        if (dt2 <= dt1) {
                            var minDate = $('#date11').datepicker('option', 'minDate');
                            $('#date11').datepicker('setDate', minDate);
                        }
                    }
                });

            } else {
                $("#date1").datepicker({
                    dateFormat: "yy-mm-dd",
                    minDate: jdate,
                    maxDate: maxdate,
                    beforeShowDay: noHoilday,
                    onSelect: function (date) {
                        $('#error1').hide();
                        var city = $("#citysub").val();
                        var service_name = $("#service_name").val();

                        $('#timepicker1').text('Select Time');
                        $('#time1').val('');
                        $('#form1 #svn').val(service_name);
                        var date2 = $('#date1').datepicker('getDate');
                        date2.setDate(date2.getDate() + 3);
                        gettimeSlot(service_name, 1, city, $('#date1').datepicker('getDate'));
                        $('#date11').datepicker('setDate', date2);
                        //sets minDate to dt1 date + 1
                        $('#date11').datepicker('option', 'minDate', date2);
                    }
                });

                $("#date11").datepicker({
                    dateFormat: "yy-mm-dd",
                    minDate: 3,
                    maxDate: 90,
                    beforeShowDay: noHoilday,
                    onClose: function () {
                        var dt1 = $('#date1').datepicker('getDate');
                        //console.log(dt1);
                        var dt2 = $('#date11').datepicker('getDate');
                        if (dt2 <= dt1) {
                            var minDate = $('#date11').datepicker('option', 'minDate');
                            $('#date11').datepicker('setDate', minDate);
                        }
                    }
                });

            }
        }
    });
}

function getTimeSlotsForDay(date, st, stm, et, etm, dur, de) {
    if (de === 1) {
        var timeSlots = []
        var dayStart = new Date(date)
        var dayEnd = new Date(date)

        switch (date.getDay()) {
            //case 0: //Sunday
            //return timeSlots;

            default:
                dayStart.setHours(st, stm, 0, 0)
                dayEnd.setHours(et, etm, 0, 0)
        }
        do {
            timeSlots.push(new Date(dayStart))

            dayStart.setHours(dayStart.getHours(), dayStart.getMinutes() + dur)

        } while (dayStart < dayEnd);

        return timeSlots
    } else {
        var timeSlots = []
        var dayStart = new Date(date)
        var dayEnd = new Date(date)

        switch (date.getDay()) {
            //case 0: //Sunday
            //return timeSlots;

            default:
                dayStart.setHours(st, stm, 0, 0)
                dayEnd.setHours(et, etm, 0, 0)
        }
        do {
            timeSlots.push(new Date(dayStart))

            dayStart.setHours(dayStart.getHours(), dayStart.getMinutes() + dur)

        } while (dayStart <= dayEnd);

        return timeSlots
    }

}

function ISOcoverttime(duration) {
    var match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/)

    var hours = (parseInt(match[1]) || 0);
    var minutes = (parseInt(match[2]) || 0);
    var seconds = (parseInt(match[3]) || 0);

    return hours * 60 + minutes;
}

function gettimeSlot(a, b, city, ndate) {
    var geo_lat = localStorage.getItem("geo_lat");
    var geo_lon = localStorage.getItem("geo_lon");
    var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "service_id": ' + a + '}';
    var count = 0;
    $.ajax({
        type: 'POST',
        url: '//api.zimmber.com/timeslots/v2/getTimeSlots',
        //url: '//apitest.zimmber.com/timeslots/v2/getTimeSlots',
        data: {data: da},
        dataType: 'json',
        success: function (data) {
            var jdate = data.minDate;
            var json_date = data.minDate;
            var json_time = data.minTime;
            var json_startTime = data.startTime;
            var time_part_array_start = json_startTime.split(" : ");
            if (time_part_array_start[0] != '10') {
                var time_part_array_start_final = time_part_array_start[0].replace("0", "");
            } else {
                var time_part_array_start_final = time_part_array_start[0];
            }
            $('#mrngstrt').html(time_part_array_start_final + ' AM');
            if (json_startTime == '12 : 00 : AM') {
                var json_startTime = '00 : 00 : AM';
            }
            if (json_startTime == '12 : 30 : AM') {
                var json_startTime = '00 : 30 : AM';
            }
            var json_endTime = data.endTime;
            var time_part_array_end = json_endTime.split(" : ");
            if (time_part_array_end[0] == '11') {
                $('#evnend').html('Midnight');
            } else {
                if (time_part_array_end[0] != '10') {
                    var time_part_array_end_final = time_part_array_end[0].replace("0", "");
                } else {
                    var time_part_array_end_final = time_part_array_end[0];
                }
                $('#evnend').html(time_part_array_end_final + ' PM');
            }
            var json_type = data.slotType;
            var json_max = data.maxDays;
            var json_sdm = data.slotDuration;

            var nfrom = ndate.split("-");
            var gdate = new Date(nfrom[0], nfrom[1] - 1, nfrom[2]);


            var durationTime = ISOcoverttime(json_sdm);

            var json_surge = data.surgeList;

            if (parseInt(gdate.getMonth() + 1) < 10) {
                var gmon = '0' + (gdate.getMonth() + 1);
            } else {
                var gmon = (gdate.getMonth() + 1);
            }
            if (parseInt(gdate.getDate()) < 10) {
                var gda = '0' + gdate.getDate();
            } else {
                var gda = gdate.getDate();
            }

            var mdate = gdate.getFullYear() + '-' + gmon + '-' + gda;

            var arr = [];
            var sur = [];
            json_surge.map(function (surge) {
                if (surge.date == mdate) {
                    arr.push(surge.time);
                    sur.push(surge.surge);
                }
            });

            var arrs = [arr];
            var from = jdate.split("-");
            var fdate = new Date(from[0], from[1] - 1, from[2]);

            var startTime = json_startTime.split(":");

            if (startTime[2] == ' PM') {
                startTime[0] = parseInt(startTime[0].trim()) + 12
            }
            var endTime = json_endTime.split(":");

            if (endTime[2] == ' PM') {
                endTime[0] = parseInt(endTime[0].trim()) + 12
            }

            if (gdate <= fdate) {
                var jtime = json_time.split(":");
                jtime[0] = jtime[0].trim();
                if (jtime[2] == ' PM' && jtime[0] < 12) {
                    jtime[0] = parseInt(jtime[0]) + 12
                }

                var distime = jtime[0] + '.' + jtime[1].trim();

            } else {
                var distime = 0;
            }

            $('#morning1').empty();
            $('#afternoon1').empty();
            $('#evening1').empty();

            //var today = new Date();
            var today = gdate;
            var lastDay = new Date(today);
            lastDay.setDate(today.getDate() + 1);


            if (json_type === "variable") {
                var va = 1;

            } else {
                var va = 0;
                //endTime[0] = endTime[0] + durationTime;
            }

            //console.log(new Date(today));
            var message = "";
            for (var i = new Date(today); i < lastDay; i.setDate(i.getDate() + 1)) {

                //message += i.toDateString() + ":\n"
                message += getTimeSlotsForDay(i, startTime[0], startTime[1], endTime[0], endTime[1], durationTime, va).map(function (it) {
                    var ve = it.toTimeString().match(/(\d\d:\d\d:\d\d)/)[0];
                    var time_part_array = ve.split(":");
                    var ampm = 'AM';
                    var ampms = 'AM';
                    if (time_part_array[0] < 12) {
                        var m = 1;
                    }
                    if (time_part_array[0] >= 12 && time_part_array[0] < 16) {
                        var m = 2;
                    }
                    if (time_part_array[0] >= 16) {
                        var m = 3;
                    }

                    if (time_part_array[0] >= 12) {
                        ampm = 'PM';
                    }

                    var gentime = time_part_array[0] + '.' + time_part_array[1];

                    if (time_part_array[0] > 12) {
                        time_part_array[0] = time_part_array[0] - 12;
                        if (time_part_array[0] < 10) {
                            time_part_array[0] = '0' + time_part_array[0]
                        }
                    }

                    var formatted_time = time_part_array[0] + ' : ' + time_part_array[1] + ' : ' + ampm;
                    var formatted_time2 = time_part_array[0] + ' : ' + time_part_array[1] + ' ' + ampm;

                    var formatted_time3 = "";

                    formatted_time3 = Number(time_part_array[0]) + (Number(durationTime) / 60);

                    if (formatted_time3 >= 12) {
                        ampms = 'PM';
                    } else {
                        ampms = ampm;
                    }

                    if (formatted_time3 > 12) {
                        var formatted_time3 = formatted_time3 - 12;
                    }
                    if (formatted_time3 < 10) {
                        formatted_time3 = '0' + formatted_time3
                    }

                    if (time_part_array[0] == 00) {
                        var formatted_time2 = '12 : ' + time_part_array[1] + ' ' + ampm;
                    }


                    formatted_time3 = formatted_time3 + ' : ' + time_part_array[1] + ' ' + ampms;

                    if (json_type === "variable") {
                        if (distime > gentime) {
                            alink = '<div class="col-md-6 padding_l_r"><div class="dis" >' + formatted_time2 + ' - ' + formatted_time3 + '</div></div>';
                        }
                        else {
                            if ($.inArray(formatted_time, arr) > -1) {
                                var get = $.inArray(formatted_time, arr);
                                if (sur[get] > 0) {
                                    //alink = '<div class="col-md-6 padding_l_r"><a href="javascript:;" title="Surge price applicable" class="su timeSelect" rel="'+formatted_time+'" onclick="addtimetoslot('+sur[get]+', this)">'+formatted_time2+' - '+formatted_time3+'</a></div>';
                                    if (sur[get] < 1) {
                                        alink = '<div class="col-md-6 padding_l_r"><a href="javascript:;" title="Discount price applicable" class="plunge timeSelect" rel="' + formatted_time + '" onclick="addtimetoslot(' + sur[get] + ', this)">' + formatted_time2 + ' - ' + formatted_time3 + '</a></div>';
                                    } else {
                                        alink = '<div class="col-md-6 padding_l_r"><a href="javascript:;" title="Surge price applicable" class="su timeSelect" rel="' + formatted_time + '" onclick="addtimetoslot(' + sur[get] + ', this)">' + formatted_time2 + ' - ' + formatted_time3 + '</a></div>';
                                    }
                                } else {
                                    alink = '<div class="col-md-6 padding_l_r"><div class="dis" >' + formatted_time2 + ' - ' + formatted_time3 + '</div></div>';
                                }
                            } else {
                                alink = '<div class="col-md-6 padding_l_r"><a class="timeSelect" href="javascript:;" title="" rel="' + formatted_time + '" onclick="addtimetoslot(' + b + ', this)">' + formatted_time2 + ' - ' + formatted_time3 + '</a></div>';
                            }
                        }
                    }
                    else {
                        if (distime > gentime) {
                            alink = '<div class="col-md-3 padding_l_r"><div class="dis" >' + formatted_time2 + '</div></div>';
                        }
                        else {
                            if ($.inArray(formatted_time, arr) > -1) {
                                var get = $.inArray(formatted_time, arr);
                                if (sur[get] > 0) {
                                    //alink = '<div class="col-md-3 padding_l_r"><a href="javascript:;" title="Surge price applicable" class="su timeSelect" rel="'+formatted_time+'" onclick="addtimetoslot('+sur[get]+', this)">'+formatted_time2+'</a></div>';
                                    if (sur[get] < 1) {
                                        alink = '<div class="col-md-3 padding_l_r"><a href="javascript:;" title="Discount price applicable" class="plunge timeSelect" rel="' + formatted_time + '" onclick="addtimetoslot(' + sur[get] + ', this)">' + formatted_time2 + '</a></div>';
                                    } else {
                                        alink = '<div class="col-md-3 padding_l_r"><a href="javascript:;" title="Surge price applicable" class="su timeSelect" rel="' + formatted_time + '" onclick="addtimetoslot(' + sur[get] + ', this)">' + formatted_time2 + '</a></div>';
                                    }
                                } else {
                                    alink = '<div class="col-md-3 padding_l_r"><div class="dis" >' + formatted_time2 + '</div></div>';
                                }
                            } else {
                                alink = '<div class="col-md-3 padding_l_r"><a class="timeSelect" href="javascript:;" title="" rel="' + formatted_time + '" onclick="addtimetoslot(' + b + ', this)">' + formatted_time2 + '</a></div>';
                            }
                        }
                    }


                    if (ampm = 'AM' && m == 1) {
                        //document.getElementById('time').innerHTML += alink;
                        $('#morning1').append(alink);
                        if (count == 0 && alink.indexOf("timeSelect") > -1) {
                            if (alink.indexOf("addtimetoslot(") > -1) {
                                var surval = alink.split("addtimetoslot(")[1];
                                surval = surval.split(",")[0];
                            } else {
                                var surval = 1;
                            }

                            addtimetoslot(surval, $("#morning1:first-child a")[0]);
                            if ($("#collapseFour").is(':visible')) {

                            } else {
                                $("#four").click();
                            }
                            count = 1;
                        }
                    }

                    if (ampm = 'PM' && m == 2) {
                        $('#afternoon1').append(alink);
                        if (count == 0 && alink.indexOf("timeSelect") > -1) {
                            if (alink.indexOf("addtimetoslot(") > -1) {
                                var surval = alink.split("addtimetoslot(")[1];
                                surval = surval.split(",")[0];
                            } else {
                                var surval = 1;
                            }
                            addtimetoslot(surval, $("#afternoon1:first-child a")[0]);
                            if ($("#collapseFive").is(':visible')) {

                            } else {
                                $("#five").click();
                            }
                            count = 1;
                        }
                    }

                    if (ampm = 'PM' && m == 3) {
                        $('#evening1').append(alink);
                        if (count == 0 && alink.indexOf("timeSelect") > -1) {
                            if (alink.indexOf("addtimetoslot(") > -1) {
                                var surval = alink.split("addtimetoslot(")[1];
                                surval = surval.split(",")[0];
                            } else {
                                var surval = 1;
                            }
                            addtimetoslot(surval, $("#evening1:first-child a")[0]);
                            if ($("#collapseSix").is(':visible')) {

                            } else {
                                $("#six").click();
                            }
                            count = 1;
                        }
                    }


                    //console.log(alink);
                    //return ve;
                });

            }
        }
    });

}

function addtimetoslot(a, rel) {
    $('#timepicker1').text(rel.getAttribute('rel'));
    $('#time1').val(rel.getAttribute('rel'));
    $('#sur_pr').val(a);
    if (a < 1) {
        var pul = (10 - parseInt(a * 10)) / 10;
        $(".surgeButton").html((pul * 100) + "% Off");
        $(".surgeButton").css("border", "1px dashed #362975");
        $(".surgeButton").css("color", "#362975");
        $("#surge").html("Happy Hour! " + (pul * 100) + "% discount on the selected time-slot");
        $("#surge").css("color", "#362975");
        $("#surge").show();
        $(".surgeButton").show();
    } else if (a > 1) {
        $(".surgeButton").html(a + "x Surge");
        $(".surgeButton").css("border", "1px dashed #ee7522");
        $(".surgeButton").css("color", "#ee7522");
        $("#surge").html("Demand is at peak! " + a + "x surge on this time-slot");
        $("#surge").css("color", "#ee7522");
        $("#surge").show();
        $(".surgeButton").show();
    } else {
        $(".surgeButton").html("");
        $("#surge").hide();
        $(".surgeButton").hide();
    }
    $('#mtime').text(', ' + rel.innerHTML);
    $('#viewTime').text(', ' + rel.innerHTML);
    $('.timeSelect').removeClass('active');
    $(rel).addClass('active');
    $('#time_error').fadeOut();
    /*$('#timing_open').toggleClass('hidden show');*/
    timeslot_clicked();
}
function quikr_url(url) {
    var city = localStorage.getItem("geo_city_id");
    service_url_city = url.replace('$city_id', city);
    window.open(service_url_city, '_blank');
}
function verfityO() {
    var token = $('#token').val();
    $('.book_btn').attr("onclick", "");
    if (token == null || token == "") {
        $('#error_d').text('Please enter correct OTP').show();
        $('.book_btn').attr("onclick", "verfityO()");
        return false;
    }
    var customer_verify = {};
    customer_verify['mobile'] = $("#phone").val();
    customer_verify['otp'] = token;
    customer_verify['AdeviceType'] = 'web';
    // var datastring = $("#otpverify").serialize();
    $.ajax({
        type: 'POST',
        url: baseUrl + "front/RejCustomerAppWebService/CustomerVerify",
        data: {'data': JSON.stringify(customer_verify)},
        success: function (result) {
            var rep_verify = JSON.parse(result);
            if (rep_verify.data.errorcode == 1) {
                mixpanel.track(
                    "Confirm OTP", {
                        "Action": "Order Completely Placed",
                        "Category": "Order",
                    }
                );
                var locationstring = window.location.href.split("?");
                var jobid = $('#job_id').val();
                if (locationstring[1]) {
                    window.location = '/order-thank-you?ordid=' + jobid + '&' + locationstring[1];
                } else {
                    window.location = '/order-thank-you?ordid=' + jobid;
                }
            }
            if (rep_verify.data.errorcode == 0) {
                $('#error_d').text("Please enter correct OTP").show();
                $('.book_btn').attr("onclick", "verfityO()");
                return false;
            }
        },
        error: function () {
            $('#error_d').text("Please enter correct OTP").show();
            $('.book_btn').attr("onclick", "verfityO()");
            return false;
        }
    });
}

function offer_click(a) {
    var text = $(a).text();
    offer_tile_clicked(text);
}

/* <![CDATA[ */
goog_snippet_vars = function () {
    var w = window;
    w.google_conversion_id = 941602932;
    w.google_conversion_label = "lAjACJf2zF8Q9PD-wAM";
    w.google_conversion_value = 0.00;
    w.google_conversion_currency = "INR";
    w.google_remarketing_only = false;
}
// DO NOT CHANGE THE CODE BELOW.
goog_report_conversion = function (url) {
    goog_snippet_vars();
    window.google_conversion_format = "3";
    var opt = new Object();
    opt.onload_callback = function () {
        if (typeof(url) != 'undefined') {
            window.location = url;
        }
    }
    var conv_handler = window['google_trackConversion'];
    if (typeof(conv_handler) == 'function') {
        conv_handler(opt);
    }
}
/* ]]> */
/*<!--  PRMPT MODAL pop up-->*/
$(document).ready(function () {
    var geo_lat = localStorage.getItem("geo_lat");
    var geo_lon = localStorage.getItem("geo_lon");
    var currentURL = window.location.href;
    var url = new URL(currentURL);
    var utmSource = url.searchParams.get("utm_source");
    console.log(utmSource);
    var da = '{"lat":' + geo_lat + ', "lng": ' + geo_lon + ', "displaymode":"frontend", "AdeviceType":"lite","utm_source": "' + utmSource + '"}';

    $.ajax({
        url: 'https://zimmber.com/front/RejCustomerAppWebService/menuList',
        contentType: "application/json; charset=utf-8",
        data: {data: da},
        dataType: 'json',
        success: function (data) {
            //console.log('--------------------');
            //console.log(data);
            //console.log('--------------------');
            var parseData = (data);
            //console.log('--------PARSE DATA------------');
            //console.log(parseData);
            //console.log('--------------------');
            var promptImage = '';
            //console.log(parseData);
            if (!!parseData) {
                promptImage = !!(parseData.data.promptImage_web) ? parseData.data.promptImage_web : '';

                // promptImage = "https://zimmber.com/images/notify/quikr1.jpg";//need tocheck y not coming from api
                //  promptImage = "./Proweb/Images/Mobile-Page-POP_UP.jpg";//need tocheck y not coming from api
                var imgBlock = '<div class=""><img src="' + promptImage + '" class="prompt-image img img-responsive"/></div>';
                $('#prompt-modal .utm_image').html(imgBlock);
            }

            if (promptImage != '') {
                $('#prompt-modal').modal('show');
            }

        }
    });

    console.log('-------------');
});