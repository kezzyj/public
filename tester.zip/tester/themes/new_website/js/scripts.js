//////////ToolTip/////////////

$(document).ready(function() {
  $("body").tooltip({ selector: '[data-toggle=tooltip]' });
});

/////////Tabs///////////

$('#myTabs a').click(function (e) {
  e.preventDefault()
  $(this).tab('show')
})

//////////Tabs Slides//////////

/*var hidWidth;
var scrollBarWidths = 40;

var widthOfList = function(){
  var itemsWidth = 0;
  $('.list li').each(function(){
    var itemWidth = $(this).outerWidth();
    itemsWidth+=itemWidth;
  });
  return itemsWidth;
};

var widthOfHidden = function(){
  return (($('.wrapper').outerWidth())-widthOfList()-getLeftPosi())-scrollBarWidths;
};

var getLeftPosi = function(){
  return $('.list').position().left;
};

var reAdjust = function(){
  if (($('.wrapper').outerWidth()) < widthOfList()) {
    $('.scroller-right').show();
  }
  else {
    $('.scroller-right').hide();
  }

  if (getLeftPosi()<0) {
    $('.scroller-left').show();
  }
  else {
    $('.item').animate({left:"-="+getLeftPosi()+"px"},'slow');
  	$('.scroller-left').hide();
  }
}

reAdjust();

$(window).on('resize',function(e){
  	reAdjust();
});

 //$('#btn_rate_card').click(function () {
  //  $(this).find('.fa-angle-down').toggleClass('is-closed');
  //  $(this).find('.rate_card_container').toggleClass('rate_card_onclick');
 //   $('#open_rate_card').slideToggle('slow');
//     reAdjust();
//    });

$('.scroller-right').click(function() {

  $('.scroller-left').fadeIn('slow');
  $('.scroller-right').fadeOut('slow');

  $('.list').animate({left:"+="+widthOfHidden()+"px"},'slow',function(){

  });
});

$('.scroller-left').click(function() {

	$('.scroller-right').fadeIn('slow');
	$('.scroller-left').fadeOut('slow');

  	$('.list').animate({left:"-="+getLeftPosi()+"px"},'slow',function(){

  	});
});   */

////////////////Menu//////////////

// Sticky Header
$(window).scroll(function() {

    if ($(window).scrollTop() > 100) {
        $('.main_h').addClass('sticky');
    } else {
        $('.main_h').removeClass('sticky');
    }
});

// Mobile Navigation
$('.mobile-toggle').click(function() {
    if ($('.main_h').hasClass('open-nav')) {
        $('.main_h').removeClass('open-nav');
    } else {
        $('.main_h').addClass('open-nav');
    }
});

$('.main_h li a').click(function() {
    if ($('.main_h').hasClass('open-nav')) {
        $('.navigation').removeClass('open-nav');
        $('.main_h').removeClass('open-nav');
    }
});

// navigation scroll lijepo radi materem
$('nav a').click(function(event) {
    var id = $(this).attr("href");
    var offset = 70;
    var target = $(id).offset().top - offset;
    $('html, body').animate({
        scrollTop: target
    }, 500);
    event.preventDefault();
});

/////////////////////DropDown///////////////////

// Dropdown Menu Fade
jQuery(document).ready(function(){
    $(".dropdown").hover(
        function() { $('.dropdown-menu', this).stop().fadeIn("fast");
        },
        function() { $('.dropdown-menu', this).stop().fadeOut("fast");
    });
});

/////////////////////OPEN TIME SLOT////////////////////////////

$(function () {

    $('.toggle').click(function (event) {
        event.preventDefault();
        var target = $(this).attr('href');
        $(target).toggleClass('hidden show');
    });

});

////////////////////////////////////////////////////////////////

$("#btn_rate_card").click(function () {

    // Set the effect type
    var effect = 'slide';

    // Set the options for the effect type chosen
    var options = { direction: "right" };

    // Set the duration (default: 400 milliseconds)
    var duration = 300;

    $("#bg_overlay").toggleClass("is-visible");

    $("body").toggleClass("overflow-hidden");

    $('#open_rate_card').toggle(effect, options, duration);

});

$("#bg_overlay").click(function () {

    // Set the effect type
    var effect = 'slide';

    // Set the options for the effect type chosen
    var options = { direction: "right" };

    // Set the duration (default: 400 milliseconds)
    var duration = 300;

    $("#bg_overlay").toggleClass("is-visible");

    $("body").toggleClass("overflow-hidden");

    $('#open_rate_card').toggle(effect, options, duration);

});

$("#close_rate_card").click(function () {

    // Set the effect type
    var effect = 'slide';

    // Set the options for the effect type chosen
    var options = { direction: "right" };

    // Set the duration (default: 400 milliseconds)
    var duration = 300;

    $("#bg_overlay").removeClass("is-visible");

    $("body").removeClass("overflow-hidden");

    $('#open_rate_card').toggle(effect, options, duration);
});

////////////////////////////////////////////////////////////////////////////////


$('#please_note').click(function () {

   $('#hover_tooltip').slideToggle('slow');
	tnc_clicked();
});

$('#please_note_close').click(function () {

   $('#hover_tooltip').slideToggle('fast');
	tnc_close_button_clicked();
});

///////////////////////////////////////////////////////////////////////////////

$('#salon_btn').click(function () {
    $(".inner_lists").animate({width: '40%'});

    $("#salon_list_detail").delay().fadeIn(3000);
    $(".salon_links").css({"float": "none", "text-align": "center"});
});

//////////////////////////////// SEND APP ////////////////////////////////////////////////

$('#booking_details').click(function () {

   $('#open_time_date').slideToggle('fast');
   datetime_clicked();
});

/* NPS RATING SUBMIT FUNCTIONS START */

$(document).ready(function(){
    $('.nps-form-errors').html('');
    $('.nps-form-errors').fadeOut();
    var selAnswerArray={};
    var json_string='';
    var others='';
    $('#btn-submit-nps').click(function(){
        var count=($('#frm-nps-questions .question_option_block').length);
        var questions_answer=$('#frm-nps-questions .question_option_block');
        $(questions_answer).each(function (index,value) {
            var q=$(this).find($('.question input[type="hidden"]')).val();
            var op=$(this).find($('.options input[type="radio"]:checked')).val();
            if((op==undefined || op=="")){
            }else{
                others=$('#other_remark').val();
                selAnswerArray[q]=op;
                json_string=JSON.stringify(selAnswerArray);
            }
        });
        if((Object.keys(selAnswerArray).length < count)){
            //validate All Questions
            //alert('Answer Required For All Questions');
            $('.nps-form-errors').html('Answer Required For All Question');
            $('.nps-form-errors').fadeIn();
        }else if((Object.keys(selAnswerArray).length == count)){
            //Submit Form Data
            if($('.options input[type="radio"]:checked').val()=="others"  && ($('.other-remark-block #other_remark').val()=="" || $('.other-remark-block #other_remark').val().length < 3) ){
                //alert('Remark Cannot Be Left Blank');
                $('.nps-form-errors').html('Remark Cannot Be Left Blank');
                $('.nps-form-errors').fadeIn();
                $('.other-remark-block #other_remark').focus();
            }else{
                $('.nps-form-errors').html('');
                $('.nps-form-errors').fadeOut();
                var rating=$('#frm-nps-questions #rating').val();
                var order_id=$('#frm-nps-questions #order-id').val();
                if(others!=''){
                    var dataString=$.param({'question_answer' :json_string, 'rating' :rating, 'order_id' :order_id,'other_remarks':others});
                }else{
                    var dataString=$.param({'question_answer' :json_string, 'rating' :rating, 'order_id' :order_id});
                }
                submitNpsRatings(dataString);
            }
        }
    });
});


function submitNpsRatings(formData){
    $.ajax({
        type: 'POST',
        data:formData,
        url: FRONT_WEBSITE_URL+'Progressive/website/SubmitNpsRating',
        beforeSend: function () {
            $('#btn-submit-nps').attr('disabled','disabled');
            $('#btn-submit-nps').val('Submitting Please Wait...');
        },
        success: function (result) {
            console.log(result);
        },
        error: function () {
            alert("Failed To Submit");
        },
        complete: function () {
            $('#btn-submit-nps').removeAttr('disabled');
            $('#btn-submit-nps').val('Submit');
            $('#frm-nps-questions').fadeOut();
            $('#thank-you').fadeIn();
        }
    });
}
/*$('#frm-nps-questions input[type="radio"]').click(function () {
    $('.nps-form-errors').html('');
    $('.nps-form-errors').fadeOut();
    if($(this).val()=="others"){
        $('.other-remark-block').fadeIn(200, function () {
            $('.other-remark-block #other_remark').focus();
        });
    }else{
        $('.other-remark-block').fadeOut(200, function () {
            $('.other-remark-block #other_remark').val('');
        });
    }
});*/

/* NPS RATING SUBMIT FUNCTIONS ENDS */